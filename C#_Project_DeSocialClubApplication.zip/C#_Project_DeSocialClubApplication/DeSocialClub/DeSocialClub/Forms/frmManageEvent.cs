﻿//*********************************************************************************************
//// -----------------------------------------------------------------------
// <copyright file="frmManageEvents.cs" Developed By = "Harshita and Priyanka">
// De Socia club - Here We can Insert  and seach Event by id and to perform delete & Update opration on any Event of the club
// </copyright>
// -----------------------------------------------------------------------

//*******************************************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DeSocialBusinessLayer;
using DeSocialDataAccessLayer;
using System.Data.SqlClient;

namespace DeSocialClub
{
    public partial class frmManageEvent : Form
    {
        public frmManageEvent()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        DeSocialBusinessLayer.Event aEvent = new DeSocialBusinessLayer.Event();
        DeSocialBusinessLayer.Events<DeSocialBusinessLayer.Event> addEvent = new DeSocialBusinessLayer.Events<DeSocialBusinessLayer.Event>();
        
        DeSocialClubDataSet aDataSet = new DeSocialClubDataSet();
        public int Flag = 0;
        public int Event_Id;

        private void btnCreateEvent_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtEventId.Text != null)
                {
                   // Validition check for data entered
                    if (txtEventName.Text != null)
                   {
                       if (txtDescription.Text != null)
                       {
                           if (txtEventCharge.Text != null)
                           {
                               if (txtVenue.Text != null)
                               {
                                   lstDisplayEventResult.Items.Clear();
                                   aEvent.Event_Id = Convert.ToInt32(txtEventId.Text);
                                   aEvent.Event_Name = txtEventName.Text;
                                   aEvent.Event_Description = txtDescription.Text;
                                   aEvent.Event_DateTime = dtpDate.Value;
                                   aEvent.Event_Charge = Convert.ToDouble(txtEventCharge.Text);
                                   aEvent.Event_Venue = txtVenue.Text;

                                   if (Flag == 0)
                                   {
                                       addEvent.Add(aEvent);
                                       lstDisplayEventResult.Items.Add(aEvent.ToString());
                                       aDataSet.AcceptChanges();
                                       lstDisplayEventResult.Items.Add("Event Added Successfully !!");
                                   }
                                   else
                                   {
                                       addEvent.Update(aEvent);
                                       ClearEvent();
                                       lstDisplayEventResult.Items.Add("Event Updated Successfully !!");
                                   }
                               }
                               else
                                   MessageBox.Show("Please provide Event Venue");
                           }
                           else
                               MessageBox.Show("Please provide Event Charge");
                       }
                       else
                           MessageBox.Show("Please provide Event Description");
                   }
                   else
                       MessageBox.Show("Please provide Event Name");
               }
               else
                    MessageBox.Show("Please provide Event Id");
           }
           catch (Exception exp)
           {
               MessageBox.Show(exp.Message);
           }
        }

        private void btnEventReset_Click(object sender, EventArgs e)
        {
            lstDisplayEventResult.Items.Clear();
            ClearEvent();
        }

        private void btnEventDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (Flag == 1)
                {
                    SqlDataReader dr = aEvent.GetEvent(Convert.ToInt32(txtEventId.Text));
                    if (dr.HasRows)
                    {
                        lstDisplayEventResult.Items.Clear();
                        aEvent.Event_Id = Convert.ToInt32(txtEventId.Text);
                        aEvent.Event_Name = txtEventName.Text;
                        aEvent.Event_Description = txtDescription.Text;
                        aEvent.Event_DateTime = dtpDate.Value;
                        aEvent.Event_Charge = Convert.ToDouble(txtEventCharge.Text);
                        aEvent.Event_Venue = txtVenue.Text;
                        aEvent.DeleteEvent();
                        txtEventId.Clear();
                        txtEventName.Clear();
                        txtDescription.Clear();
                        dtpDate.Text = "";
                        txtEventCharge.Clear();
                        txtVenue.Clear();
                    }
                    else
                        throw new InvalidOperationException("ID does not exist!! please enter valid Event ID."); 
                }
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEventSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.TryParse(txtEventId.Text, out Event_Id))
                {
                    SqlDataReader dr = aEvent.GetEvent(Convert.ToInt32(txtEventId.Text));
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            int val = dr.GetInt32(dr.GetOrdinal("Event_Id"));
                            txtEventId.Text = val.ToString();
                            txtEventName.Text = dr.GetString(1);
                            txtDescription.Text = dr.GetString(2);
                            dtpDate.Value = dr.GetDateTime(3);
                            double eventCharge = dr.GetDouble(4);
                            txtEventCharge.Text = eventCharge.ToString();
                            txtVenue.Text = dr.GetString(5);
                        }
                        Flag = 1;
                    }
                    else
                    {
                        // If Id does not exist in database then flag set to 0
                        Flag = 0;
                        throw new InvalidOperationException("ID does not exist!! please enter valid  Activity ID.");
                    }
                }
                else
                {
                    MessageBox.Show("Enter numeric data for the Activity id", "Error");
                }
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void ClearEvent()
        {
            txtDescription.Clear();
            txtEventCharge.Clear();
            txtEventId.Clear();
            txtEventName.Clear();
            txtVenue.Clear();
        }
    }
}