﻿//*********************************************************************************************
//// -----------------------------------------------------------------------
// <copyright file="frmManageMember.cs" Developed By = "Harshita and Priyanka">
// De Socia club - Here We can seach member by id and perform delete and Update to any member of the club
// </copyright>
// -----------------------------------------------------------------------

//*******************************************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DeSocialDataAccessLayer;
using DeSocialBusinessLayer;
using System.Data.SqlClient;

namespace DeSocialClub
{
    public partial class frmManageMember : Form
    {
        public frmManageMember()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        ReportLinqDataContext data = new ReportLinqDataContext();
        DeSocialBusinessLayer.Member aMember = new DeSocialBusinessLayer.Member();
        DeSocialClubDataSet aDataSet = new DeSocialClubDataSet();
        int Flag = 0;
        bool maritalStatus;
        int Member_Id;

        private void btnMemberUpdate_Click(object sender, EventArgs e)
        {
            if(rbtnMSingle.Checked == true)
                maritalStatus = false;
            else
                maritalStatus = true;
            try
            {
                if (txtMID.Text != null)
                {
                    if (txtMName.Text != null)
                    {
                        if (txtMEmailID.Text != null)
                        {
                            if (txtMContact.Text != null)
                            {
                                if (txtMAddress.Text != null)
                                {
                                    if (maritalStatus != null)
                                    {
                                        if (txtMFamilyMember.Text != null)
                                        {
                                            if (lstMSportsActivities.Text != null)
                                            {
                                                InitializeProperties();
                                                if (Flag == 1)
                                                {                                                                                                     
                                                    aMember.UpdateMember();
                                                    ClearMember();
                                                    lstDisplayMemberResult.Items.Add("Member Updated Successfully !!");
                                                }
                                                else
                                                    MessageBox.Show("Member Id does not exist");
                                            }
                                            else
                                                MessageBox.Show("Please select sports Activities");
                                        }
                                        else
                                            MessageBox.Show("Please provide Family Count");
                                    }
                                    else
                                        MessageBox.Show("Please provide Marital Status");
                                }
                                else
                                    MessageBox.Show("Please provide Address");
                            }
                            else
                                MessageBox.Show("Please provide Contact");
                        }
                        else
                            MessageBox.Show("Please provide Email Id");
                    }
                    else
                        MessageBox.Show("Please provide Name");
                }
                else
                    MessageBox.Show("Please provide Member Id");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        public void ClearMember()
        {
            txtMID.Clear();
            txtMName.Clear();
            txtMEmailID.Clear();
            txtMContact.Clear();
            txtMAddress.Clear();
            rbtnMSingle.Checked = false;
            rbtnMMarried.Checked = false;
            txtMFamilyMember.Clear();
            lstMSportsActivities.SelectedIndex = -1;
        }

        public void InitializeProperties()
        {
            lstDisplayMemberResult.Items.Clear();
            aMember.Member_Id = Convert.ToInt32(txtMID.Text);
            aMember.Name = txtMName.Text;
            aMember.Contact = txtMContact.Text;
            aMember.Email_Id = txtMEmailID.Text;
            aMember.Address = txtMAddress.Text;
            aMember.IsMarried = Convert.ToBoolean(maritalStatus);
            aMember.Family_Count = Convert.ToInt32(txtMFamilyMember.Text);
            aMember.Facility = cmbMFacility.Text;
            aMember.Membership_Type = cmbMMembershipType.Text;
            
            string[] activityArray = new string[lstMSportsActivities.SelectedIndices.Count];
            for (int i = 0; i < lstMSportsActivities.SelectedIndices.Count; i++)
            {
                activityArray[i] = lstMSportsActivities.Items[lstMSportsActivities.SelectedIndices[i]].ToString();
                aMember.Activity += activityArray[i] + ",";
            }
        }

        private void frmManageMember_Load(object sender, EventArgs e)
        {
            var command = (from Activities in data.Activities orderby Activities.Activity_Name select Activities.Activity_Name);
            lstMSportsActivities.DataSource = command.ToList();
            lstMSportsActivities.SelectedIndex = -1;
        }

        private void btnMemberDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (Flag == 1)
                {
                        aMember.Member_Id = Convert.ToInt32(txtMID.Text);
                        InitializeProperties();
                        aMember.DeleteMember();
                        ClearMember();
                        lstDisplayMemberResult.Items.Add("Member Deleted Successfully !!");
                }
                else
                    throw new InvalidOperationException("ID does not exist!! please enter valid Event ID.");
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnResetMember_Click(object sender, EventArgs e)
        {
            ClearMember();
            lstDisplayMemberResult.Items.Clear();
        }

        private void btnSearchMember_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.TryParse(txtMID.Text, out Member_Id))
                {
                    SqlDataReader dr = aMember.GetMember(Convert.ToInt32(txtMID.Text));

                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            aMember.Dob = dr.GetDateTime(dr.GetOrdinal("Dob"));
                            
                            int val = dr.GetInt32(dr.GetOrdinal("Member_Id"));
                            txtMID.Text = val.ToString();
                            txtMName.Text = dr.GetString(1);
                            txtMEmailID.Text = dr.GetString(3);
                            txtMContact.Text = dr.GetString(4);
                            txtMAddress.Text = dr.GetString(5);
                            aMember.Gender = dr.GetString(6);
                            bool val1 = dr.GetBoolean(7);
                            if (val1 == true)
                                rbtnMMarried.Checked = true;
                            else
                                rbtnMSingle.Checked = true;

                            int val2 = dr.GetInt32(dr.GetOrdinal("Family_Count"));
                            txtMFamilyMember.Text = val2.ToString();
                            cmbMFacility.Text = dr.GetString(9);
                            cmbMMembershipType.Text = dr.GetString(10);

                            string str = dr.GetString(11);
                            string[] values = str.Split(',');
                            foreach (var item in values)
                            {
                                lstMSportsActivities.Text = item;
                            }

                            aMember.Charge = dr.GetDouble(dr.GetOrdinal("Fee"));
                        }
                        Flag = 1;
                    }
                    else
                    {
                        // If Id does not exist in database then flag set to 0
                        Flag = 0;
                        throw new InvalidOperationException("ID does not exist!! please enter valid  Activity ID.");
                    }
                }

                else
                {
                    MessageBox.Show("Enter numeric data for the Activity id", "Error");
                }
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}