﻿//*********************************************************************************************
//// -----------------------------------------------------------------------
// <copyright file="frmManageActivities.cs" Developed By = "Harshita and Priyanka">
// De Socia club - Here We can Insert  and seach Activity by id and to perform delete & Update opration on any activity of the club
// </copyright>
// -----------------------------------------------------------------------

//*******************************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DeSocialBusinessLayer;
using DeSocialDataAccessLayer;
using System.Data.SqlClient;

namespace DeSocialClub
{
   public partial class frmManageActivities : Form
   {
       public frmManageActivities()
       {
           InitializeComponent();
           this.FormBorderStyle = FormBorderStyle.FixedDialog;
           this.StartPosition = FormStartPosition.CenterScreen;
           this.MaximizeBox = false;
           this.MinimizeBox = false;
       }

       // Instanciating Activity Class by creating object
       DeSocialBusinessLayer.Activity aActivity = new DeSocialBusinessLayer.Activity();
       
       // dataset object
       DeSocialClubDataSet aDataSet = new DeSocialClubDataSet();

       // flag variable to check status
       public static int Flag = 0;
       public int Activity_Id;

       //Method to clear fields 
       public void ClearActivity()
       {
           txtActivityId.Clear();
           txtActivityName.Clear();
           txtActivityDescription.Clear();
       }

//***************** Delete Button code for deleting activity from database *************************************
       private void btnDeleteActivity_Click(object sender, EventArgs e)
       {
           try
           {
              // to check whether record Present in database
              if (Flag == 1)
               {
                   SqlDataReader dr = aActivity.GetActivity(Convert.ToInt32(txtActivityId.Text));

                   if (dr.HasRows)
                   {
                          lstDisplayResult.Items.Clear();

                          aActivity.Activity_Id = Convert.ToInt32(txtActivityId.Text);
                          aActivity.Activity_Name = txtActivityName.Text;
                          aActivity.Activity_Description = txtActivityDescription.Text;

                          aActivity.Delete();
                          ClearActivity();
                          lstDisplayResult.Items.Add("Activity Deleted Successfully !!");
                   }                 
                   else
                       throw new InvalidOperationException("ID does not exist!! please enter valid  Activity ID.");                        
               }            
           }
           catch (InvalidOperationException ex)
           {
               MessageBox.Show(ex.Message);
           }           
       }

// **************************** Reset Button to Clear all fields from form *****************************************
       private void btnResetActivity_Click(object sender, EventArgs e)
       {
           lstDisplayResult.Items.Clear();
           ClearActivity();
       }

       //**************************************** Search Button to check database for existing record, to perfor Delete and Update Opration *************
       private void btnActivitySearch_Click(object sender, EventArgs e)
       {
           try
           {
               if (int.TryParse(txtActivityId.Text, out Activity_Id))
               {
                   SqlDataReader dr = aActivity.GetActivity(Convert.ToInt32(txtActivityId.Text));

                   if (dr.HasRows)
                   {
                       while (dr.Read())
                       {
                           int val = dr.GetInt32(dr.GetOrdinal("Activity_Id"));
                           txtActivityId.Text = val.ToString();
                           txtActivityName.Text = dr.GetString(1);
                           txtActivityDescription.Text = dr.GetString(2);
                       }
                       Flag = 1;
                   }
                   else
                   {
                       // If Id does not exist in database then flag set to 0
                       Flag = 0;
                       throw new InvalidOperationException("ID does not exist!! please enter valid  Activity ID.");
                   }
               }
               else
               {
                   MessageBox.Show("Enter numeric data for the Activity id", "Error");
               }
           }
           catch (InvalidOperationException ex)
           {
               MessageBox.Show(ex.Message);
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
       }

       // **************************** Save Button code for Insertion and Updation Opration ********************************
       private void btnSaveActivity_Click(object sender, EventArgs e)
       {
           try
           {
               if (txtActivityId.Text != null)
               {
                   // Validition check for data entered
                   if (txtActivityDescription.Text != null)
                   {
                       if (txtActivityName.Text != null)
                       {
                           lstDisplayResult.Items.Clear();

                           aActivity.Activity_Id = Convert.ToInt32(txtActivityId.Text);
                           aActivity.Activity_Name = txtActivityName.Text;
                           aActivity.Activity_Description = txtActivityDescription.Text;
                           if (Flag == 0)
                           {
                               aActivity.Add();
                               ClearActivity();
                               lstDisplayResult.Items.Add(aActivity.ToString());
                               aDataSet.AcceptChanges();
                           }
                           else
                           {
                               aActivity.Update();
                               ClearActivity();
                               lstDisplayResult.Items.Add("Activity Updated Successfully !!");
                           }
                       }
                       else
                           MessageBox.Show("Please provide Activity Description");
                   }
                   else
                       MessageBox.Show("Please provide Activity Name");
               }
               else
                   MessageBox.Show("Please provide Activity Id");
           }
           catch (Exception exp)
           {
               MessageBox.Show(exp.Message);
           }
       }
   }
}