﻿//*********************************************************************************************
//// -----------------------------------------------------------------------
// <copyright file="MDIDeSocialClub.cs" Developed By = "Harshita and Priyanka">
// De Socia club - Parent form for providing multiple interface
// </copyright>
// -----------------------------------------------------------------------

//*******************************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeSocialClub
{
    public partial class DeSocialClubMDI : Form
    {
        public DeSocialClubMDI()
        {
            InitializeComponent();
        }

        private void mnsLogin_Click(object sender, EventArgs e)
        {
            frmLogin aLogin = new frmLogin();
            aLogin.MdiParent = this;
            aLogin.Show();            
        }

        private void mnsMemberRegistration_Click(object sender, EventArgs e)
        {
            frmMemberRegistration aMemberRegistration = new frmMemberRegistration();
            aMemberRegistration.MdiParent = this;
            aMemberRegistration.Show();
        }

        private void mnsExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnsManageEvent_Click(object sender, EventArgs e)
        {
            frmManageEvent aManageEvent = new frmManageEvent();
            aManageEvent.MdiParent = this;
            aManageEvent.Show();
        }

        private void mnsManageActivities_Click(object sender, EventArgs e)
        {
            frmManageActivities aManageActivities = new frmManageActivities();
            aManageActivities.MdiParent = this;
            aManageActivities.Show();
        }

       private void manageMemberToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmManageMember aManageMember = new frmManageMember();
            aManageMember.MdiParent = this;
            aManageMember.Show(); 
        }

        private void mnsReport_Click(object sender, EventArgs e)
        {
            frmReport aReport = new frmReport();
            aReport.MdiParent = this;
            aReport.Show();
        }
    }
}