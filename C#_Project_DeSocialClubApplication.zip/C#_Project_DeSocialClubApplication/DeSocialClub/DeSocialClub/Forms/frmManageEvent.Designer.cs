﻿namespace DeSocialClub
{
    partial class frmManageEvent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEventReset = new System.Windows.Forms.Button();
            this.btnEventDelete = new System.Windows.Forms.Button();
            this.btnSaveEvent = new System.Windows.Forms.Button();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.txtEventCharge = new System.Windows.Forms.TextBox();
            this.txtVenue = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtEventName = new System.Windows.Forms.TextBox();
            this.txtEventId = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnEventSearch = new System.Windows.Forms.Button();
            this.lstDisplayEventResult = new System.Windows.Forms.ListBox();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnEventReset
            // 
            this.btnEventReset.Location = new System.Drawing.Point(367, 378);
            this.btnEventReset.Name = "btnEventReset";
            this.btnEventReset.Size = new System.Drawing.Size(75, 34);
            this.btnEventReset.TabIndex = 16;
            this.btnEventReset.Text = "Reset";
            this.btnEventReset.UseVisualStyleBackColor = true;
            this.btnEventReset.Click += new System.EventHandler(this.btnEventReset_Click);
            // 
            // btnEventDelete
            // 
            this.btnEventDelete.Location = new System.Drawing.Point(263, 378);
            this.btnEventDelete.Name = "btnEventDelete";
            this.btnEventDelete.Size = new System.Drawing.Size(75, 34);
            this.btnEventDelete.TabIndex = 15;
            this.btnEventDelete.Text = "Delete";
            this.btnEventDelete.UseVisualStyleBackColor = true;
            this.btnEventDelete.Click += new System.EventHandler(this.btnEventDelete_Click);
            // 
            // btnSaveEvent
            // 
            this.btnSaveEvent.Location = new System.Drawing.Point(26, 378);
            this.btnSaveEvent.Name = "btnSaveEvent";
            this.btnSaveEvent.Size = new System.Drawing.Size(100, 34);
            this.btnSaveEvent.TabIndex = 13;
            this.btnSaveEvent.Text = "Save";
            this.btnSaveEvent.UseVisualStyleBackColor = true;
            this.btnSaveEvent.Click += new System.EventHandler(this.btnCreateEvent_Click);
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(114, 175);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(200, 20);
            this.dtpDate.TabIndex = 7;
            // 
            // txtEventCharge
            // 
            this.txtEventCharge.Location = new System.Drawing.Point(114, 211);
            this.txtEventCharge.Name = "txtEventCharge";
            this.txtEventCharge.Size = new System.Drawing.Size(82, 20);
            this.txtEventCharge.TabIndex = 9;
            // 
            // txtVenue
            // 
            this.txtVenue.Location = new System.Drawing.Point(114, 251);
            this.txtVenue.Name = "txtVenue";
            this.txtVenue.Size = new System.Drawing.Size(200, 20);
            this.txtVenue.TabIndex = 11;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(31, 214);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(72, 13);
            this.label33.TabIndex = 8;
            this.label33.Text = "Event Charge";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(31, 177);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(64, 13);
            this.label32.TabIndex = 6;
            this.label32.Text = "Date / Time";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(31, 251);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(38, 13);
            this.label31.TabIndex = 10;
            this.label31.Text = "Venue";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(114, 88);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(284, 70);
            this.txtDescription.TabIndex = 5;
            // 
            // txtEventName
            // 
            this.txtEventName.Location = new System.Drawing.Point(114, 57);
            this.txtEventName.Name = "txtEventName";
            this.txtEventName.Size = new System.Drawing.Size(100, 20);
            this.txtEventName.TabIndex = 3;
            // 
            // txtEventId
            // 
            this.txtEventId.Location = new System.Drawing.Point(114, 20);
            this.txtEventId.Name = "txtEventId";
            this.txtEventId.Size = new System.Drawing.Size(100, 20);
            this.txtEventId.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(23, 91);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(60, 13);
            this.label30.TabIndex = 4;
            this.label30.Text = "Description";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(23, 57);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(66, 13);
            this.label29.TabIndex = 2;
            this.label29.Text = "Event Name";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(23, 23);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(49, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "Event ID";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btnEventSearch);
            this.groupBox7.Controls.Add(this.lstDisplayEventResult);
            this.groupBox7.Controls.Add(this.btnEventReset);
            this.groupBox7.Controls.Add(this.btnEventDelete);
            this.groupBox7.Controls.Add(this.btnSaveEvent);
            this.groupBox7.Controls.Add(this.dtpDate);
            this.groupBox7.Controls.Add(this.txtEventCharge);
            this.groupBox7.Controls.Add(this.txtVenue);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.txtDescription);
            this.groupBox7.Controls.Add(this.txtEventName);
            this.groupBox7.Controls.Add(this.txtEventId);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Location = new System.Drawing.Point(4, -1);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(479, 434);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Event";
            // 
            // btnEventSearch
            // 
            this.btnEventSearch.Location = new System.Drawing.Point(158, 377);
            this.btnEventSearch.Name = "btnEventSearch";
            this.btnEventSearch.Size = new System.Drawing.Size(75, 35);
            this.btnEventSearch.TabIndex = 14;
            this.btnEventSearch.Text = "Search";
            this.btnEventSearch.UseVisualStyleBackColor = true;
            this.btnEventSearch.Click += new System.EventHandler(this.btnEventSearch_Click);
            // 
            // lstDisplayEventResult
            // 
            this.lstDisplayEventResult.FormattingEnabled = true;
            this.lstDisplayEventResult.Location = new System.Drawing.Point(6, 290);
            this.lstDisplayEventResult.Name = "lstDisplayEventResult";
            this.lstDisplayEventResult.Size = new System.Drawing.Size(463, 69);
            this.lstDisplayEventResult.TabIndex = 12;
            // 
            // frmManageEvent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 440);
            this.Controls.Add(this.groupBox7);
            this.Name = "frmManageEvent";
            this.Text = "frmManageEvent";
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEventReset;
        private System.Windows.Forms.Button btnEventDelete;
        private System.Windows.Forms.Button btnSaveEvent;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.TextBox txtEventCharge;
        private System.Windows.Forms.TextBox txtVenue;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtEventName;
        private System.Windows.Forms.TextBox txtEventId;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ListBox lstDisplayEventResult;
        private System.Windows.Forms.Button btnEventSearch;
    }
}