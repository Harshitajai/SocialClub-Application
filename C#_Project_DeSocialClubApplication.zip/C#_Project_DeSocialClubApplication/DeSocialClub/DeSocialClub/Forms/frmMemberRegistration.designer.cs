﻿namespace DeSocialClub
{
    partial class frmMemberRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grpboxMembers = new System.Windows.Forms.GroupBox();
            this.txtFamilyMembers = new System.Windows.Forms.TextBox();
            this.grpMaritalStatus = new System.Windows.Forms.GroupBox();
            this.rbtnMarried = new System.Windows.Forms.RadioButton();
            this.rbtnSingle = new System.Windows.Forms.RadioButton();
            this.grpGender = new System.Windows.Forms.GroupBox();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtMemberId = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rbtnPlatinum = new System.Windows.Forms.RadioButton();
            this.rbtnGold = new System.Windows.Forms.RadioButton();
            this.rbtnStandard = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.lblOverallCharge = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.lblTotalMembers = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnMemberReset = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstSportsActivities = new System.Windows.Forms.ListBox();
            this.llbMembershipDetail = new System.Windows.Forms.LinkLabel();
            this.chkConfirmMember = new System.Windows.Forms.CheckBox();
            this.lblMembershipFee = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnBoth = new System.Windows.Forms.RadioButton();
            this.rbtnEvents = new System.Windows.Forms.RadioButton();
            this.rbtnSportsClub = new System.Windows.Forms.RadioButton();
            this.grpFacilities = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.memberBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lstDisplayMemberResult = new System.Windows.Forms.ListBox();
            this.grpboxMembers.SuspendLayout();
            this.grpMaritalStatus.SuspendLayout();
            this.grpGender.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpFacilities.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.memberBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // grpboxMembers
            // 
            this.grpboxMembers.Controls.Add(this.txtFamilyMembers);
            this.grpboxMembers.Controls.Add(this.grpMaritalStatus);
            this.grpboxMembers.Controls.Add(this.grpGender);
            this.grpboxMembers.Controls.Add(this.txtAddress);
            this.grpboxMembers.Controls.Add(this.txtContact);
            this.grpboxMembers.Controls.Add(this.txtEmail);
            this.grpboxMembers.Controls.Add(this.dtpDOB);
            this.grpboxMembers.Controls.Add(this.txtName);
            this.grpboxMembers.Controls.Add(this.txtMemberId);
            this.grpboxMembers.Controls.Add(this.label10);
            this.grpboxMembers.Controls.Add(this.label9);
            this.grpboxMembers.Controls.Add(this.label8);
            this.grpboxMembers.Controls.Add(this.label7);
            this.grpboxMembers.Controls.Add(this.label6);
            this.grpboxMembers.Controls.Add(this.label5);
            this.grpboxMembers.Controls.Add(this.label4);
            this.grpboxMembers.Controls.Add(this.label3);
            this.grpboxMembers.Controls.Add(this.label2);
            this.grpboxMembers.Location = new System.Drawing.Point(5, 0);
            this.grpboxMembers.Name = "grpboxMembers";
            this.grpboxMembers.Size = new System.Drawing.Size(384, 427);
            this.grpboxMembers.TabIndex = 90;
            this.grpboxMembers.TabStop = false;
            this.grpboxMembers.Text = "Member";
            // 
            // txtFamilyMembers
            // 
            this.txtFamilyMembers.Location = new System.Drawing.Point(131, 380);
            this.txtFamilyMembers.Name = "txtFamilyMembers";
            this.txtFamilyMembers.Size = new System.Drawing.Size(200, 20);
            this.txtFamilyMembers.TabIndex = 21;
            // 
            // grpMaritalStatus
            // 
            this.grpMaritalStatus.Controls.Add(this.rbtnMarried);
            this.grpMaritalStatus.Controls.Add(this.rbtnSingle);
            this.grpMaritalStatus.Location = new System.Drawing.Point(131, 319);
            this.grpMaritalStatus.Name = "grpMaritalStatus";
            this.grpMaritalStatus.Size = new System.Drawing.Size(180, 42);
            this.grpMaritalStatus.TabIndex = 17;
            this.grpMaritalStatus.TabStop = false;
            // 
            // rbtnMarried
            // 
            this.rbtnMarried.AutoSize = true;
            this.rbtnMarried.Location = new System.Drawing.Point(111, 16);
            this.rbtnMarried.Name = "rbtnMarried";
            this.rbtnMarried.Size = new System.Drawing.Size(60, 17);
            this.rbtnMarried.TabIndex = 19;
            this.rbtnMarried.TabStop = true;
            this.rbtnMarried.Text = "Married";
            this.rbtnMarried.UseVisualStyleBackColor = true;
            // 
            // rbtnSingle
            // 
            this.rbtnSingle.AutoSize = true;
            this.rbtnSingle.Location = new System.Drawing.Point(20, 16);
            this.rbtnSingle.Name = "rbtnSingle";
            this.rbtnSingle.Size = new System.Drawing.Size(54, 17);
            this.rbtnSingle.TabIndex = 18;
            this.rbtnSingle.TabStop = true;
            this.rbtnSingle.Text = "Single";
            this.rbtnSingle.UseVisualStyleBackColor = true;
            // 
            // grpGender
            // 
            this.grpGender.Controls.Add(this.rbtnFemale);
            this.grpGender.Controls.Add(this.rbtnMale);
            this.grpGender.Location = new System.Drawing.Point(131, 262);
            this.grpGender.Name = "grpGender";
            this.grpGender.Size = new System.Drawing.Size(180, 51);
            this.grpGender.TabIndex = 13;
            this.grpGender.TabStop = false;
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.Location = new System.Drawing.Point(110, 20);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(59, 17);
            this.rbtnFemale.TabIndex = 15;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female";
            this.rbtnFemale.UseVisualStyleBackColor = true;
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.Location = new System.Drawing.Point(19, 20);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(48, 17);
            this.rbtnMale.TabIndex = 14;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male";
            this.rbtnMale.UseVisualStyleBackColor = true;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(131, 226);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(200, 20);
            this.txtAddress.TabIndex = 11;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(131, 186);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(200, 20);
            this.txtContact.TabIndex = 9;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(131, 145);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(200, 20);
            this.txtEmail.TabIndex = 7;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(131, 104);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 20);
            this.dtpDOB.TabIndex = 5;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(131, 65);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(200, 20);
            this.txtName.TabIndex = 3;
            // 
            // txtMemberId
            // 
            this.txtMemberId.Location = new System.Drawing.Point(131, 24);
            this.txtMemberId.Name = "txtMemberId";
            this.txtMemberId.Size = new System.Drawing.Size(200, 20);
            this.txtMemberId.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 280);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "Gender";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 383);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Family Members";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 337);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Marital Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 189);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Contact ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Email ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Date of Birth";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Member ID";
            // 
            // rbtnPlatinum
            // 
            this.rbtnPlatinum.AutoSize = true;
            this.rbtnPlatinum.Location = new System.Drawing.Point(16, 61);
            this.rbtnPlatinum.Name = "rbtnPlatinum";
            this.rbtnPlatinum.Size = new System.Drawing.Size(65, 17);
            this.rbtnPlatinum.TabIndex = 32;
            this.rbtnPlatinum.TabStop = true;
            this.rbtnPlatinum.Text = "Platinum";
            this.rbtnPlatinum.UseVisualStyleBackColor = true;
            this.rbtnPlatinum.CheckedChanged += new System.EventHandler(this.rbtnPlatinum_CheckedChanged);
            // 
            // rbtnGold
            // 
            this.rbtnGold.AutoSize = true;
            this.rbtnGold.Location = new System.Drawing.Point(16, 38);
            this.rbtnGold.Name = "rbtnGold";
            this.rbtnGold.Size = new System.Drawing.Size(47, 17);
            this.rbtnGold.TabIndex = 31;
            this.rbtnGold.TabStop = true;
            this.rbtnGold.Text = "Gold";
            this.rbtnGold.UseVisualStyleBackColor = true;
            this.rbtnGold.CheckedChanged += new System.EventHandler(this.rbtnGold_CheckedChanged);
            // 
            // rbtnStandard
            // 
            this.rbtnStandard.AutoSize = true;
            this.rbtnStandard.Location = new System.Drawing.Point(16, 15);
            this.rbtnStandard.Name = "rbtnStandard";
            this.rbtnStandard.Size = new System.Drawing.Size(68, 17);
            this.rbtnStandard.TabIndex = 30;
            this.rbtnStandard.TabStop = true;
            this.rbtnStandard.Text = "Standard";
            this.rbtnStandard.UseVisualStyleBackColor = true;
            this.rbtnStandard.CheckedChanged += new System.EventHandler(this.rbtnStandard_CheckedChanged);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.lblOverallCharge);
            this.groupBox13.Controls.Add(this.label40);
            this.groupBox13.Controls.Add(this.lblTotalMembers);
            this.groupBox13.Controls.Add(this.label35);
            this.groupBox13.Location = new System.Drawing.Point(5, 516);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(447, 60);
            this.groupBox13.TabIndex = 39;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "All Members and Total Charges";
            // 
            // lblOverallCharge
            // 
            this.lblOverallCharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOverallCharge.Location = new System.Drawing.Point(336, 23);
            this.lblOverallCharge.Name = "lblOverallCharge";
            this.lblOverallCharge.Size = new System.Drawing.Size(89, 23);
            this.lblOverallCharge.TabIndex = 43;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(237, 28);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(77, 13);
            this.label40.TabIndex = 42;
            this.label40.Text = "Overall Charge";
            // 
            // lblTotalMembers
            // 
            this.lblTotalMembers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalMembers.Location = new System.Drawing.Point(104, 24);
            this.lblTotalMembers.Name = "lblTotalMembers";
            this.lblTotalMembers.Size = new System.Drawing.Size(109, 23);
            this.lblTotalMembers.TabIndex = 41;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 29);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(77, 13);
            this.label35.TabIndex = 40;
            this.label35.Text = "Total Members";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnMemberReset);
            this.groupBox3.Controls.Add(this.btnRegister);
            this.groupBox3.Location = new System.Drawing.Point(458, 516);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(288, 60);
            this.groupBox3.TabIndex = 44;
            this.groupBox3.TabStop = false;
            // 
            // btnMemberReset
            // 
            this.btnMemberReset.Location = new System.Drawing.Point(175, 13);
            this.btnMemberReset.Name = "btnMemberReset";
            this.btnMemberReset.Size = new System.Drawing.Size(75, 37);
            this.btnMemberReset.TabIndex = 46;
            this.btnMemberReset.Text = "Reset";
            this.btnMemberReset.UseVisualStyleBackColor = true;
            this.btnMemberReset.Click += new System.EventHandler(this.btnMemberReset_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(41, 13);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 37);
            this.btnRegister.TabIndex = 45;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lstSportsActivities);
            this.groupBox2.Controls.Add(this.llbMembershipDetail);
            this.groupBox2.Controls.Add(this.chkConfirmMember);
            this.groupBox2.Controls.Add(this.lblMembershipFee);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.groupBox1);
            this.groupBox2.Controls.Add(this.grpFacilities);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Location = new System.Drawing.Point(403, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(343, 427);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Membership Detail";
            // 
            // lstSportsActivities
            // 
            this.lstSportsActivities.DisplayMember = "Activity_Name";
            this.lstSportsActivities.FormattingEnabled = true;
            this.lstSportsActivities.Location = new System.Drawing.Point(127, 243);
            this.lstSportsActivities.Name = "lstSportsActivities";
            this.lstSportsActivities.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstSportsActivities.Size = new System.Drawing.Size(197, 95);
            this.lstSportsActivities.TabIndex = 34;
            this.lstSportsActivities.ValueMember = "Activity_Name";
            this.lstSportsActivities.SelectedIndexChanged += new System.EventHandler(this.lstSportsActivities_SelectedIndexChanged);
            // 
            // llbMembershipDetail
            // 
            this.llbMembershipDetail.AutoSize = true;
            this.llbMembershipDetail.Location = new System.Drawing.Point(120, 117);
            this.llbMembershipDetail.Name = "llbMembershipDetail";
            this.llbMembershipDetail.Size = new System.Drawing.Size(160, 13);
            this.llbMembershipDetail.TabIndex = 27;
            this.llbMembershipDetail.TabStop = true;
            this.llbMembershipDetail.Text = "Click here for Membership detail ";
            // 
            // chkConfirmMember
            // 
            this.chkConfirmMember.AutoSize = true;
            this.chkConfirmMember.Location = new System.Drawing.Point(127, 359);
            this.chkConfirmMember.Name = "chkConfirmMember";
            this.chkConfirmMember.Size = new System.Drawing.Size(128, 17);
            this.chkConfirmMember.TabIndex = 35;
            this.chkConfirmMember.Text = "Click to confirm Detail";
            this.chkConfirmMember.UseVisualStyleBackColor = true;
            this.chkConfirmMember.CheckedChanged += new System.EventHandler(this.chkConfirmMember_CheckedChanged);
            // 
            // lblMembershipFee
            // 
            this.lblMembershipFee.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMembershipFee.Location = new System.Drawing.Point(128, 388);
            this.lblMembershipFee.Name = "lblMembershipFee";
            this.lblMembershipFee.Size = new System.Drawing.Size(100, 23);
            this.lblMembershipFee.TabIndex = 37;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(27, 388);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(85, 13);
            this.label34.TabIndex = 36;
            this.label34.Text = "Membership Fee";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(27, 250);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 13);
            this.label14.TabIndex = 33;
            this.label14.Text = "Sports Activities";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Membership Type";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnBoth);
            this.groupBox1.Controls.Add(this.rbtnEvents);
            this.groupBox1.Controls.Add(this.rbtnSportsClub);
            this.groupBox1.Location = new System.Drawing.Point(127, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(117, 84);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            // 
            // rbtnBoth
            // 
            this.rbtnBoth.AutoSize = true;
            this.rbtnBoth.Location = new System.Drawing.Point(12, 59);
            this.rbtnBoth.Name = "rbtnBoth";
            this.rbtnBoth.Size = new System.Drawing.Size(47, 17);
            this.rbtnBoth.TabIndex = 26;
            this.rbtnBoth.TabStop = true;
            this.rbtnBoth.Text = "Both";
            this.rbtnBoth.UseVisualStyleBackColor = true;
            this.rbtnBoth.CheckedChanged += new System.EventHandler(this.rbtnBoth_CheckedChanged);
            // 
            // rbtnEvents
            // 
            this.rbtnEvents.AutoSize = true;
            this.rbtnEvents.Location = new System.Drawing.Point(12, 36);
            this.rbtnEvents.Name = "rbtnEvents";
            this.rbtnEvents.Size = new System.Drawing.Size(58, 17);
            this.rbtnEvents.TabIndex = 25;
            this.rbtnEvents.TabStop = true;
            this.rbtnEvents.Text = "Events";
            this.rbtnEvents.UseVisualStyleBackColor = true;
            this.rbtnEvents.CheckedChanged += new System.EventHandler(this.rbtnEvents_CheckedChanged);
            // 
            // rbtnSportsClub
            // 
            this.rbtnSportsClub.AutoSize = true;
            this.rbtnSportsClub.Location = new System.Drawing.Point(12, 13);
            this.rbtnSportsClub.Name = "rbtnSportsClub";
            this.rbtnSportsClub.Size = new System.Drawing.Size(79, 17);
            this.rbtnSportsClub.TabIndex = 24;
            this.rbtnSportsClub.TabStop = true;
            this.rbtnSportsClub.Text = "Sports Club";
            this.rbtnSportsClub.UseVisualStyleBackColor = true;
            this.rbtnSportsClub.CheckedChanged += new System.EventHandler(this.rbtnSportsClub_CheckedChanged);
            // 
            // grpFacilities
            // 
            this.grpFacilities.Controls.Add(this.rbtnPlatinum);
            this.grpFacilities.Controls.Add(this.rbtnGold);
            this.grpFacilities.Controls.Add(this.rbtnStandard);
            this.grpFacilities.Location = new System.Drawing.Point(127, 143);
            this.grpFacilities.Name = "grpFacilities";
            this.grpFacilities.Size = new System.Drawing.Size(100, 87);
            this.grpFacilities.TabIndex = 29;
            this.grpFacilities.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "Facilities";
            // 
            // lstDisplayMemberResult
            // 
            this.lstDisplayMemberResult.FormattingEnabled = true;
            this.lstDisplayMemberResult.Location = new System.Drawing.Point(5, 433);
            this.lstDisplayMemberResult.Name = "lstDisplayMemberResult";
            this.lstDisplayMemberResult.Size = new System.Drawing.Size(741, 69);
            this.lstDisplayMemberResult.TabIndex = 38;
            // 
            // frmMemberRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 586);
            this.Controls.Add(this.lstDisplayMemberResult);
            this.Controls.Add(this.grpboxMembers);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Name = "frmMemberRegistration";
            this.Text = "frmMemberRegistration";
            this.Load += new System.EventHandler(this.frmMemberRegistration_Load);
            this.grpboxMembers.ResumeLayout(false);
            this.grpboxMembers.PerformLayout();
            this.grpMaritalStatus.ResumeLayout(false);
            this.grpMaritalStatus.PerformLayout();
            this.grpGender.ResumeLayout(false);
            this.grpGender.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpFacilities.ResumeLayout(false);
            this.grpFacilities.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.memberBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpboxMembers;
        private System.Windows.Forms.TextBox txtFamilyMembers;
        private System.Windows.Forms.GroupBox grpMaritalStatus;
        private System.Windows.Forms.RadioButton rbtnMarried;
        private System.Windows.Forms.RadioButton rbtnSingle;
        private System.Windows.Forms.GroupBox grpGender;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.RadioButton rbtnMale;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtMemberId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbtnPlatinum;
        private System.Windows.Forms.RadioButton rbtnGold;
        private System.Windows.Forms.RadioButton rbtnStandard;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label lblOverallCharge;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label lblTotalMembers;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnMemberReset;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstSportsActivities;
        private System.Windows.Forms.LinkLabel llbMembershipDetail;
        private System.Windows.Forms.CheckBox chkConfirmMember;
        private System.Windows.Forms.Label lblMembershipFee;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnBoth;
        private System.Windows.Forms.RadioButton rbtnEvents;
        private System.Windows.Forms.RadioButton rbtnSportsClub;
        private System.Windows.Forms.GroupBox grpFacilities;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.BindingSource memberBindingSource;
        private System.Windows.Forms.ListBox lstDisplayMemberResult;
    }
}