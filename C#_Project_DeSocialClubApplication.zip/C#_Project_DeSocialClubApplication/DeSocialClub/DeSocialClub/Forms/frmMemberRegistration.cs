﻿//*********************************************************************************************
//// -----------------------------------------------------------------------
// <copyright file="frmRegisterMember.cs" Developed By = "Harshita and Priyanka">
// De Socia club - Here We can Register member here and know about how many member's are there in club and what is the Overall charge 
// </copyright>
// -----------------------------------------------------------------------

//*******************************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DeSocialDataAccessLayer;

namespace DeSocialClub
{
    public partial class frmMemberRegistration : Form
    {
        ReportLinqDataContext data = new ReportLinqDataContext();
        DeSocialBusinessLayer.Member aMember = new DeSocialBusinessLayer.Member();

        public frmMemberRegistration()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        DeSocialClubDataSet aDataSet = new DeSocialClubDataSet();
        private void btnRegister_Click(object sender, EventArgs e)
        {
            bool check;
            chkConfirmMember.Checked = false;
            chkConfirmMember.Enabled = false;
            try
            {
                if (txtMemberId.Text != null)
                {
                    if (txtName.Text != null)
                    {
                        if (txtEmail.Text != null)
                        {
                            if (txtContact.Text != null)
                            {
                                if (txtAddress.Text != null)
                                {
                                    if (txtFamilyMembers.Text != null)
                                    {
                                        if (lstSportsActivities.Text != null)
                                        {
                                            MemberInitializeProperties();
                                            aMember.AgeChecked += OnAgeChecked;
                                            check = aMember.Add();

                                            if (check == true) 
                                            {
                                                aMember.AddMember();
                                                aDataSet.AcceptChanges();

                                                var command = (from member in data.Members orderby member.Member_Id select member).ToList().Count();
                                                lblTotalMembers.Text = command.ToString();

                                                var command1 = (from member in data.Members orderby member.Member_Id select member.Fee).ToList().Sum();
                                                lblOverallCharge.Text = command1.ToString();
                                                lstDisplayMemberResult.Items.Add("Member Added Successfully !!");
                                            }                                         
                                        }
                                        else
                                            MessageBox.Show("Please select sports Activities");
                                    }
                                    else
                                        MessageBox.Show("Please provide Family Count");
                                }
                                else
                                    MessageBox.Show("Please provide Address");
                            }
                            else
                                MessageBox.Show("Please provide Contact");
                        }
                        else
                            MessageBox.Show("Please provide Email Id");
                    }
                    else
                        MessageBox.Show("Please provide Name");
                }
                else
                    MessageBox.Show("Please provide Member Id");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        void OnAgeChecked(object sender, EventArgs e)
        {
            MessageBox.Show("To be a Club Member Age should be more than 18 years!!");
        }

        public void MemberInitializeProperties()
        {
            lstDisplayMemberResult.Items.Clear();
            aMember.Member_Id = Convert.ToInt32(txtMemberId.Text);
            aMember.Name = txtName.Text;
            aMember.Contact = txtContact.Text;
            aMember.Email_Id = txtEmail.Text;
            aMember.Address = txtAddress.Text;
            aMember.Dob = dtpDOB.Value;

            if (rbtnFemale.Checked == true)
                aMember.Gender = rbtnFemale.Text;
            else if (rbtnMale.Checked == true)
                aMember.Gender = rbtnMale.Text;
            bool maritalStatus;
            if (rbtnSingle.Checked == true)
                maritalStatus = false;
            else
                maritalStatus = true;
            aMember.IsMarried = Convert.ToBoolean(maritalStatus);
            aMember.Family_Count = Convert.ToInt32(txtFamilyMembers.Text);
            string[] activityArray = new string[lstSportsActivities.SelectedIndices.Count];
            for (int i = 0; i < lstSportsActivities.SelectedIndices.Count; i++)
            {
                activityArray[i] = lstSportsActivities.Items[lstSportsActivities.SelectedIndices[i]].ToString();
                aMember.Activity += activityArray[i] + ",";
            }
            aMember.Charge = Convert.ToDouble(lblMembershipFee.Text);
        }

        private void frmMemberRegistration_Load(object sender, EventArgs e)
        {
            var command = (from Activities in data.Activities orderby Activities.Activity_Name select Activities.Activity_Name);
            lstSportsActivities.DataSource = command.ToList();
            chkConfirmMember.Checked = false;
            chkConfirmMember.Enabled = false;
        }

        private void llbMembershipDetail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmMembershipDetail detail = new frmMembershipDetail();
            detail.Show();
        }

        private void rbtnSportsClub_CheckedChanged(object sender, EventArgs e)
        {
            lstSportsActivities.Enabled = true;
        }

        private void rbtnEvents_CheckedChanged(object sender, EventArgs e)
        {
            lstSportsActivities.Enabled = false;
        }

        private void rbtnBoth_CheckedChanged(object sender, EventArgs e)
        {
            lstSportsActivities.Enabled = true;
        }

        private void chkConfirmMember_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnSportsClub.Checked == true)
                aMember.Facility = rbtnSportsClub.Text;
            else if (rbtnEvents.Checked == true)
                aMember.Facility = rbtnEvents.Text;
            else if (rbtnBoth.Checked == true)
                aMember.Facility = rbtnBoth.Text;
            else
                MessageBox.Show("Please select facility");

            if (rbtnStandard.Checked == true)
                aMember.Membership_Type = rbtnStandard.Text;
            else if (rbtnGold.Checked == true)
                aMember.Membership_Type = rbtnGold.Text;
            else if (rbtnPlatinum.Checked == true)
                aMember.Membership_Type = rbtnPlatinum.Text;
            else
                MessageBox.Show("Please select membership type");
            lblMembershipFee.Text = aMember.CalculateTotalCharge().ToString();
        }

        private void lstSportsActivities_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((rbtnSportsClub.Checked == true || rbtnBoth.Checked == true) && rbtnStandard.Checked == true)
            {
                 if (lstSportsActivities.SelectedItems.Count > 3)
                 {
                    MessageBox.Show("You can choose only 3 activities");
                    int index = lstSportsActivities.SelectedIndex;
                    lstSportsActivities.SetSelected(index, false);
                 }
            }
            else if ((rbtnSportsClub.Checked == true || rbtnBoth.Checked == true) && rbtnGold.Checked == true)
            {
                if (lstSportsActivities.SelectedItems.Count > 5)
                {
                     MessageBox.Show("You can choose only 5 activities");
                     int index = lstSportsActivities.SelectedIndex;
                     lstSportsActivities.SetSelected(index, false);
                }
            }
        }

        private void btnMemberReset_Click(object sender, EventArgs e)
        {
            txtMemberId.Clear();
            txtName.Clear();
            dtpDOB.Value = DateTime.Today;
            txtEmail.Clear();
            txtContact.Clear();
            txtAddress.Clear();
            rbtnMale.Checked = false;
            rbtnFemale.Checked = false;
            rbtnMarried.Checked = false;
            rbtnSingle.Checked = false;
            txtFamilyMembers.Clear();
            rbtnStandard.Checked = false;
            rbtnGold.Checked = false;
            rbtnPlatinum.Checked = false;
            rbtnSportsClub.Checked = false;
            rbtnEvents.Checked = false;
            rbtnBoth.Checked = false;
            lstSportsActivities.SelectedIndex = -1;
            lblMembershipFee.Text = "";
            lblOverallCharge.Text = "";
            lblTotalMembers.Text = "";
            chkConfirmMember.Checked = false;
            chkConfirmMember.Enabled = false;
        }

        private void rbtnStandard_CheckedChanged(object sender, EventArgs e)
        {
            chkConfirmMember.Enabled = true;
        }

        private void rbtnGold_CheckedChanged(object sender, EventArgs e)
        {
            chkConfirmMember.Enabled = true;
        }

        private void rbtnPlatinum_CheckedChanged(object sender, EventArgs e)
        {
            chkConfirmMember.Enabled = true;
        }
    }
}