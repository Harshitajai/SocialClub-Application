﻿namespace DeSocialClub
{
    partial class frmReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnActivityClear = new System.Windows.Forms.Button();
            this.btnActivitySearch = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.btnViewAllActivity = new System.Windows.Forms.Button();
            this.dgvDisplayActivity = new System.Windows.Forms.DataGridView();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.tabActivityReport = new System.Windows.Forms.TabPage();
            this.cmbActivityId = new System.Windows.Forms.ComboBox();
            this.btnEventClear = new System.Windows.Forms.Button();
            this.btnEventSearch = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnViewAllEvent = new System.Windows.Forms.Button();
            this.dgvDisplayEvent = new System.Windows.Forms.DataGridView();
            this.cmbMembershipType = new System.Windows.Forms.ComboBox();
            this.cmbFacility = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnMemberReport = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnMemberViewAll = new System.Windows.Forms.Button();
            this.dgvDisplayMember = new System.Windows.Forms.DataGridView();
            this.tabMemberReport = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabEventReport = new System.Windows.Forms.TabPage();
            this.cmbEventID = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayActivity)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.tabActivityReport.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayEvent)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayMember)).BeginInit();
            this.tabMemberReport.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabEventReport.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnActivityClear
            // 
            this.btnActivityClear.Location = new System.Drawing.Point(569, 15);
            this.btnActivityClear.Name = "btnActivityClear";
            this.btnActivityClear.Size = new System.Drawing.Size(75, 32);
            this.btnActivityClear.TabIndex = 3;
            this.btnActivityClear.Text = "Clear";
            this.btnActivityClear.UseVisualStyleBackColor = true;
            this.btnActivityClear.Click += new System.EventHandler(this.btnActivityClear_Click);
            // 
            // btnActivitySearch
            // 
            this.btnActivitySearch.Location = new System.Drawing.Point(466, 15);
            this.btnActivitySearch.Name = "btnActivitySearch";
            this.btnActivitySearch.Size = new System.Drawing.Size(75, 32);
            this.btnActivitySearch.TabIndex = 2;
            this.btnActivitySearch.Text = "Search";
            this.btnActivitySearch.UseVisualStyleBackColor = true;
            this.btnActivitySearch.Click += new System.EventHandler(this.btnActivitySearch_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(19, 18);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(55, 13);
            this.label39.TabIndex = 0;
            this.label39.Text = "Activity ID";
            // 
            // btnViewAllActivity
            // 
            this.btnViewAllActivity.Location = new System.Drawing.Point(560, 16);
            this.btnViewAllActivity.Name = "btnViewAllActivity";
            this.btnViewAllActivity.Size = new System.Drawing.Size(75, 32);
            this.btnViewAllActivity.TabIndex = 4;
            this.btnViewAllActivity.Text = "View All";
            this.btnViewAllActivity.UseVisualStyleBackColor = true;
            this.btnViewAllActivity.Click += new System.EventHandler(this.btnViewAllActivity_Click);
            // 
            // dgvDisplayActivity
            // 
            this.dgvDisplayActivity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDisplayActivity.Location = new System.Drawing.Point(6, 54);
            this.dgvDisplayActivity.Name = "dgvDisplayActivity";
            this.dgvDisplayActivity.Size = new System.Drawing.Size(632, 291);
            this.dgvDisplayActivity.TabIndex = 5;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btnViewAllActivity);
            this.groupBox10.Controls.Add(this.dgvDisplayActivity);
            this.groupBox10.Location = new System.Drawing.Point(9, 65);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(644, 351);
            this.groupBox10.TabIndex = 16;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Display Activity";
            // 
            // tabActivityReport
            // 
            this.tabActivityReport.Controls.Add(this.cmbActivityId);
            this.tabActivityReport.Controls.Add(this.groupBox10);
            this.tabActivityReport.Controls.Add(this.btnActivityClear);
            this.tabActivityReport.Controls.Add(this.btnActivitySearch);
            this.tabActivityReport.Controls.Add(this.label39);
            this.tabActivityReport.Location = new System.Drawing.Point(4, 22);
            this.tabActivityReport.Name = "tabActivityReport";
            this.tabActivityReport.Padding = new System.Windows.Forms.Padding(3);
            this.tabActivityReport.Size = new System.Drawing.Size(667, 429);
            this.tabActivityReport.TabIndex = 2;
            this.tabActivityReport.Text = "Activity Report";
            this.tabActivityReport.UseVisualStyleBackColor = true;
            // 
            // cmbActivityId
            // 
            this.cmbActivityId.FormattingEnabled = true;
            this.cmbActivityId.Location = new System.Drawing.Point(120, 16);
            this.cmbActivityId.Name = "cmbActivityId";
            this.cmbActivityId.Size = new System.Drawing.Size(121, 21);
            this.cmbActivityId.TabIndex = 1;
            // 
            // btnEventClear
            // 
            this.btnEventClear.Location = new System.Drawing.Point(560, 18);
            this.btnEventClear.Name = "btnEventClear";
            this.btnEventClear.Size = new System.Drawing.Size(75, 30);
            this.btnEventClear.TabIndex = 3;
            this.btnEventClear.Text = "Clear";
            this.btnEventClear.UseVisualStyleBackColor = true;
            this.btnEventClear.Click += new System.EventHandler(this.btnEventClear_Click);
            // 
            // btnEventSearch
            // 
            this.btnEventSearch.Location = new System.Drawing.Point(463, 18);
            this.btnEventSearch.Name = "btnEventSearch";
            this.btnEventSearch.Size = new System.Drawing.Size(75, 30);
            this.btnEventSearch.TabIndex = 2;
            this.btnEventSearch.Text = "Search";
            this.btnEventSearch.UseVisualStyleBackColor = true;
            this.btnEventSearch.Click += new System.EventHandler(this.btnEventSearch_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(17, 18);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(49, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "Event ID";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btnViewAllEvent);
            this.groupBox9.Controls.Add(this.dgvDisplayEvent);
            this.groupBox9.Location = new System.Drawing.Point(13, 54);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(640, 362);
            this.groupBox9.TabIndex = 14;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Display Events";
            // 
            // btnViewAllEvent
            // 
            this.btnViewAllEvent.Location = new System.Drawing.Point(556, 12);
            this.btnViewAllEvent.Name = "btnViewAllEvent";
            this.btnViewAllEvent.Size = new System.Drawing.Size(75, 30);
            this.btnViewAllEvent.TabIndex = 4;
            this.btnViewAllEvent.Text = "View All";
            this.btnViewAllEvent.UseVisualStyleBackColor = true;
            this.btnViewAllEvent.Click += new System.EventHandler(this.btnViewAllEvent_Click);
            // 
            // dgvDisplayEvent
            // 
            this.dgvDisplayEvent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDisplayEvent.Location = new System.Drawing.Point(6, 48);
            this.dgvDisplayEvent.Name = "dgvDisplayEvent";
            this.dgvDisplayEvent.Size = new System.Drawing.Size(628, 308);
            this.dgvDisplayEvent.TabIndex = 5;
            // 
            // cmbMembershipType
            // 
            this.cmbMembershipType.FormattingEnabled = true;
            this.cmbMembershipType.Items.AddRange(new object[] {
            "Standard",
            "Gold",
            "Platinum"});
            this.cmbMembershipType.Location = new System.Drawing.Point(108, 11);
            this.cmbMembershipType.Name = "cmbMembershipType";
            this.cmbMembershipType.Size = new System.Drawing.Size(121, 21);
            this.cmbMembershipType.TabIndex = 1;
            // 
            // cmbFacility
            // 
            this.cmbFacility.FormattingEnabled = true;
            this.cmbFacility.Items.AddRange(new object[] {
            "Sports Club",
            "Events",
            "Both"});
            this.cmbFacility.Location = new System.Drawing.Point(302, 9);
            this.cmbFacility.Name = "cmbFacility";
            this.cmbFacility.Size = new System.Drawing.Size(121, 21);
            this.cmbFacility.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 14);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Membership Type";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(257, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "Facility";
            // 
            // btnMemberReport
            // 
            this.btnMemberReport.Location = new System.Drawing.Point(561, 9);
            this.btnMemberReport.Name = "btnMemberReport";
            this.btnMemberReport.Size = new System.Drawing.Size(75, 23);
            this.btnMemberReport.TabIndex = 5;
            this.btnMemberReport.Text = "Clear";
            this.btnMemberReport.UseVisualStyleBackColor = true;
            this.btnMemberReport.Click += new System.EventHandler(this.btnMemberReport_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(464, 9);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click_1);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnMemberViewAll);
            this.groupBox4.Controls.Add(this.dgvDisplayMember);
            this.groupBox4.Location = new System.Drawing.Point(6, 33);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(647, 388);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            // 
            // btnMemberViewAll
            // 
            this.btnMemberViewAll.Location = new System.Drawing.Point(555, 19);
            this.btnMemberViewAll.Name = "btnMemberViewAll";
            this.btnMemberViewAll.Size = new System.Drawing.Size(75, 23);
            this.btnMemberViewAll.TabIndex = 6;
            this.btnMemberViewAll.Text = "View All";
            this.btnMemberViewAll.UseVisualStyleBackColor = true;
            this.btnMemberViewAll.Click += new System.EventHandler(this.btnMemberViewAll_Click);
            // 
            // dgvDisplayMember
            // 
            this.dgvDisplayMember.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDisplayMember.Location = new System.Drawing.Point(19, 50);
            this.dgvDisplayMember.Name = "dgvDisplayMember";
            this.dgvDisplayMember.Size = new System.Drawing.Size(616, 325);
            this.dgvDisplayMember.TabIndex = 3;
            // 
            // tabMemberReport
            // 
            this.tabMemberReport.Controls.Add(this.btnMemberReport);
            this.tabMemberReport.Controls.Add(this.btnSearch);
            this.tabMemberReport.Controls.Add(this.groupBox4);
            this.tabMemberReport.Controls.Add(this.cmbFacility);
            this.tabMemberReport.Controls.Add(this.label15);
            this.tabMemberReport.Controls.Add(this.label16);
            this.tabMemberReport.Controls.Add(this.cmbMembershipType);
            this.tabMemberReport.Location = new System.Drawing.Point(4, 22);
            this.tabMemberReport.Name = "tabMemberReport";
            this.tabMemberReport.Padding = new System.Windows.Forms.Padding(3);
            this.tabMemberReport.Size = new System.Drawing.Size(667, 429);
            this.tabMemberReport.TabIndex = 0;
            this.tabMemberReport.Text = "Member Report";
            this.tabMemberReport.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabMemberReport);
            this.tabControl1.Controls.Add(this.tabEventReport);
            this.tabControl1.Controls.Add(this.tabActivityReport);
            this.tabControl1.Location = new System.Drawing.Point(2, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(675, 455);
            this.tabControl1.TabIndex = 1;
            // 
            // tabEventReport
            // 
            this.tabEventReport.Controls.Add(this.cmbEventID);
            this.tabEventReport.Controls.Add(this.groupBox9);
            this.tabEventReport.Controls.Add(this.btnEventClear);
            this.tabEventReport.Controls.Add(this.btnEventSearch);
            this.tabEventReport.Controls.Add(this.label28);
            this.tabEventReport.Location = new System.Drawing.Point(4, 22);
            this.tabEventReport.Name = "tabEventReport";
            this.tabEventReport.Padding = new System.Windows.Forms.Padding(3);
            this.tabEventReport.Size = new System.Drawing.Size(667, 429);
            this.tabEventReport.TabIndex = 1;
            this.tabEventReport.Text = "Event Report";
            this.tabEventReport.UseVisualStyleBackColor = true;
            // 
            // cmbEventID
            // 
            this.cmbEventID.FormattingEnabled = true;
            this.cmbEventID.Location = new System.Drawing.Point(91, 15);
            this.cmbEventID.Name = "cmbEventID";
            this.cmbEventID.Size = new System.Drawing.Size(121, 21);
            this.cmbEventID.TabIndex = 1;
            // 
            // frmReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 463);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmReport";
            this.Text = "frmReport";
            this.Load += new System.EventHandler(this.frmReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayActivity)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.tabActivityReport.ResumeLayout(false);
            this.tabActivityReport.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayEvent)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayMember)).EndInit();
            this.tabMemberReport.ResumeLayout(false);
            this.tabMemberReport.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabEventReport.ResumeLayout(false);
            this.tabEventReport.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnActivityClear;
        private System.Windows.Forms.Button btnActivitySearch;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button btnViewAllActivity;
        private System.Windows.Forms.DataGridView dgvDisplayActivity;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TabPage tabActivityReport;
        private System.Windows.Forms.Button btnEventClear;
        private System.Windows.Forms.Button btnEventSearch;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btnViewAllEvent;
        private System.Windows.Forms.DataGridView dgvDisplayEvent;
        private System.Windows.Forms.ComboBox cmbMembershipType;
        private System.Windows.Forms.ComboBox cmbFacility;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnMemberReport;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgvDisplayMember;
        private System.Windows.Forms.TabPage tabMemberReport;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabEventReport;
        private System.Windows.Forms.Button btnMemberViewAll;
        private System.Windows.Forms.ComboBox cmbEventID;
        private System.Windows.Forms.ComboBox cmbActivityId;
    }
}