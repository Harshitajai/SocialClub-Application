﻿namespace DeSocialClub
{
    partial class frmManageMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstMSportsActivities = new System.Windows.Forms.ListBox();
            this.btnMemberDelete = new System.Windows.Forms.Button();
            this.btnMemberUpdate = new System.Windows.Forms.Button();
            this.cmbMMembershipType = new System.Windows.Forms.ComboBox();
            this.cmbMFacility = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtMFamilyMember = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.rbtnMMarried = new System.Windows.Forms.RadioButton();
            this.rbtnMSingle = new System.Windows.Forms.RadioButton();
            this.txtMAddress = new System.Windows.Forms.TextBox();
            this.txtMContact = new System.Windows.Forms.TextBox();
            this.txtMEmailID = new System.Windows.Forms.TextBox();
            this.txtMName = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.btnSearchMember = new System.Windows.Forms.Button();
            this.txtMID = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnResetMember = new System.Windows.Forms.Button();
            this.lstDisplayMemberResult = new System.Windows.Forms.ListBox();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstMSportsActivities
            // 
            this.lstMSportsActivities.FormattingEnabled = true;
            this.lstMSportsActivities.Items.AddRange(new object[] {
            "Badminton",
            "Basketball",
            "Bowling",
            "Cricket",
            "Football",
            "Golf",
            "Gym",
            "Squash",
            "Swimming Pool",
            "Tennis"});
            this.lstMSportsActivities.Location = new System.Drawing.Point(127, 356);
            this.lstMSportsActivities.Name = "lstMSportsActivities";
            this.lstMSportsActivities.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstMSportsActivities.Size = new System.Drawing.Size(197, 43);
            this.lstMSportsActivities.TabIndex = 21;
            // 
            // btnMemberDelete
            // 
            this.btnMemberDelete.Location = new System.Drawing.Point(188, 489);
            this.btnMemberDelete.Name = "btnMemberDelete";
            this.btnMemberDelete.Size = new System.Drawing.Size(75, 23);
            this.btnMemberDelete.TabIndex = 24;
            this.btnMemberDelete.Text = "Delete";
            this.btnMemberDelete.UseVisualStyleBackColor = true;
            this.btnMemberDelete.Click += new System.EventHandler(this.btnMemberDelete_Click);
            // 
            // btnMemberUpdate
            // 
            this.btnMemberUpdate.Location = new System.Drawing.Point(61, 489);
            this.btnMemberUpdate.Name = "btnMemberUpdate";
            this.btnMemberUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnMemberUpdate.TabIndex = 23;
            this.btnMemberUpdate.Text = "Update";
            this.btnMemberUpdate.UseVisualStyleBackColor = true;
            this.btnMemberUpdate.Click += new System.EventHandler(this.btnMemberUpdate_Click);
            // 
            // cmbMMembershipType
            // 
            this.cmbMMembershipType.FormattingEnabled = true;
            this.cmbMMembershipType.Items.AddRange(new object[] {
            "Standard",
            "Gold",
            "Platinum"});
            this.cmbMMembershipType.Location = new System.Drawing.Point(127, 320);
            this.cmbMMembershipType.Name = "cmbMMembershipType";
            this.cmbMMembershipType.Size = new System.Drawing.Size(121, 21);
            this.cmbMMembershipType.TabIndex = 19;
            // 
            // cmbMFacility
            // 
            this.cmbMFacility.FormattingEnabled = true;
            this.cmbMFacility.Items.AddRange(new object[] {
            "Sports Club",
            "Events",
            "Both"});
            this.cmbMFacility.Location = new System.Drawing.Point(127, 283);
            this.cmbMFacility.Name = "cmbMFacility";
            this.cmbMFacility.Size = new System.Drawing.Size(121, 21);
            this.cmbMFacility.TabIndex = 17;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(15, 373);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(82, 13);
            this.label25.TabIndex = 20;
            this.label25.Text = "Sports Activities";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(15, 323);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(91, 13);
            this.label26.TabIndex = 18;
            this.label26.Text = "Membership Type";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(15, 286);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 13);
            this.label27.TabIndex = 16;
            this.label27.Text = "Facilities";
            // 
            // txtMFamilyMember
            // 
            this.txtMFamilyMember.Location = new System.Drawing.Point(127, 246);
            this.txtMFamilyMember.Name = "txtMFamilyMember";
            this.txtMFamilyMember.Size = new System.Drawing.Size(200, 20);
            this.txtMFamilyMember.TabIndex = 15;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.rbtnMMarried);
            this.groupBox6.Controls.Add(this.rbtnMSingle);
            this.groupBox6.Location = new System.Drawing.Point(127, 190);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(200, 40);
            this.groupBox6.TabIndex = 33;
            this.groupBox6.TabStop = false;
            // 
            // rbtnMMarried
            // 
            this.rbtnMMarried.AutoSize = true;
            this.rbtnMMarried.Location = new System.Drawing.Point(113, 16);
            this.rbtnMMarried.Name = "rbtnMMarried";
            this.rbtnMMarried.Size = new System.Drawing.Size(60, 17);
            this.rbtnMMarried.TabIndex = 13;
            this.rbtnMMarried.TabStop = true;
            this.rbtnMMarried.Text = "Married";
            this.rbtnMMarried.UseVisualStyleBackColor = true;
            // 
            // rbtnMSingle
            // 
            this.rbtnMSingle.AutoSize = true;
            this.rbtnMSingle.Location = new System.Drawing.Point(22, 16);
            this.rbtnMSingle.Name = "rbtnMSingle";
            this.rbtnMSingle.Size = new System.Drawing.Size(54, 17);
            this.rbtnMSingle.TabIndex = 12;
            this.rbtnMSingle.TabStop = true;
            this.rbtnMSingle.Text = "Single";
            this.rbtnMSingle.UseVisualStyleBackColor = true;
            // 
            // txtMAddress
            // 
            this.txtMAddress.Location = new System.Drawing.Point(127, 158);
            this.txtMAddress.Name = "txtMAddress";
            this.txtMAddress.Size = new System.Drawing.Size(200, 20);
            this.txtMAddress.TabIndex = 10;
            // 
            // txtMContact
            // 
            this.txtMContact.Location = new System.Drawing.Point(127, 120);
            this.txtMContact.Name = "txtMContact";
            this.txtMContact.Size = new System.Drawing.Size(200, 20);
            this.txtMContact.TabIndex = 8;
            // 
            // txtMEmailID
            // 
            this.txtMEmailID.Location = new System.Drawing.Point(127, 84);
            this.txtMEmailID.Name = "txtMEmailID";
            this.txtMEmailID.Size = new System.Drawing.Size(200, 20);
            this.txtMEmailID.TabIndex = 6;
            // 
            // txtMName
            // 
            this.txtMName.Location = new System.Drawing.Point(127, 49);
            this.txtMName.Name = "txtMName";
            this.txtMName.Size = new System.Drawing.Size(200, 20);
            this.txtMName.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 249);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 13);
            this.label19.TabIndex = 14;
            this.label19.Text = "Family Members";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 208);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 13);
            this.label20.TabIndex = 11;
            this.label20.Text = "Marital Status";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(15, 161);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 13);
            this.label21.TabIndex = 9;
            this.label21.Text = "Address";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(15, 123);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 13);
            this.label22.TabIndex = 7;
            this.label22.Text = "Contact ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(15, 87);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 13);
            this.label23.TabIndex = 5;
            this.label23.Text = "Email ID";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(15, 52);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 13);
            this.label24.TabIndex = 3;
            this.label24.Text = "Name";
            // 
            // btnSearchMember
            // 
            this.btnSearchMember.Location = new System.Drawing.Point(333, 16);
            this.btnSearchMember.Name = "btnSearchMember";
            this.btnSearchMember.Size = new System.Drawing.Size(107, 23);
            this.btnSearchMember.TabIndex = 2;
            this.btnSearchMember.Text = "Search Member";
            this.btnSearchMember.UseVisualStyleBackColor = true;
            this.btnSearchMember.Click += new System.EventHandler(this.btnSearchMember_Click);
            // 
            // txtMID
            // 
            this.txtMID.Location = new System.Drawing.Point(127, 16);
            this.txtMID.Name = "txtMID";
            this.txtMID.Size = new System.Drawing.Size(200, 20);
            this.txtMID.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 21);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Member ID";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnResetMember);
            this.groupBox5.Controls.Add(this.lstDisplayMemberResult);
            this.groupBox5.Controls.Add(this.lstMSportsActivities);
            this.groupBox5.Controls.Add(this.btnMemberDelete);
            this.groupBox5.Controls.Add(this.btnMemberUpdate);
            this.groupBox5.Controls.Add(this.cmbMMembershipType);
            this.groupBox5.Controls.Add(this.cmbMFacility);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.txtMFamilyMember);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.txtMAddress);
            this.groupBox5.Controls.Add(this.txtMContact);
            this.groupBox5.Controls.Add(this.txtMEmailID);
            this.groupBox5.Controls.Add(this.txtMName);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.btnSearchMember);
            this.groupBox5.Controls.Add(this.txtMID);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Location = new System.Drawing.Point(5, -2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(458, 520);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            // 
            // btnResetMember
            // 
            this.btnResetMember.Location = new System.Drawing.Point(306, 489);
            this.btnResetMember.Name = "btnResetMember";
            this.btnResetMember.Size = new System.Drawing.Size(75, 23);
            this.btnResetMember.TabIndex = 25;
            this.btnResetMember.Text = "Reset";
            this.btnResetMember.UseVisualStyleBackColor = true;
            this.btnResetMember.Click += new System.EventHandler(this.btnResetMember_Click);
            // 
            // lstDisplayMemberResult
            // 
            this.lstDisplayMemberResult.FormattingEnabled = true;
            this.lstDisplayMemberResult.Location = new System.Drawing.Point(7, 410);
            this.lstDisplayMemberResult.Name = "lstDisplayMemberResult";
            this.lstDisplayMemberResult.Size = new System.Drawing.Size(445, 69);
            this.lstDisplayMemberResult.TabIndex = 22;
            // 
            // frmManageMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 519);
            this.Controls.Add(this.groupBox5);
            this.Name = "frmManageMember";
            this.Text = "frmManageMember";
            this.Load += new System.EventHandler(this.frmManageMember_Load);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstMSportsActivities;
        private System.Windows.Forms.Button btnMemberDelete;
        private System.Windows.Forms.Button btnMemberUpdate;
        private System.Windows.Forms.ComboBox cmbMMembershipType;
        private System.Windows.Forms.ComboBox cmbMFacility;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtMFamilyMember;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton rbtnMMarried;
        private System.Windows.Forms.RadioButton rbtnMSingle;
        private System.Windows.Forms.TextBox txtMAddress;
        private System.Windows.Forms.TextBox txtMContact;
        private System.Windows.Forms.TextBox txtMEmailID;
        private System.Windows.Forms.TextBox txtMName;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnSearchMember;
        private System.Windows.Forms.TextBox txtMID;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox lstDisplayMemberResult;
        private System.Windows.Forms.Button btnResetMember;
    }
}