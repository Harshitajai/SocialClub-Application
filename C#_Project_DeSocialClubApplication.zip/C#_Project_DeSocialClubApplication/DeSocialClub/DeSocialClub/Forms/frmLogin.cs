﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DeSocialDataAccessLayer;

// -----------------------------------------------------------------------
// <copyright file="frmLogin.cs" Developed By = "Harshita and Priyanka">
// De Socia club 
// </copyright>
// -----------------------------------------------------------------------

// ******************* Login form validate user login **********************

namespace DeSocialClub
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.TopMost = true;
        }

        ReportLinqDataContext data = new ReportLinqDataContext();

        //Click event to handle the login process

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                DeSocialClubMDI aMDI = new DeSocialClubMDI();
                var search = (from a in data.Logins where a.Username == txtUsername.Text && a.Password == txtPassword.Text select a).FirstOrDefault();
                if (search != null)
                {
                    Control[] controls = this.MdiParent.Controls.Find("menuStrip1", true);
                    foreach (Control ctrl in controls)
                    {
                        if (ctrl.Name == "menuStrip1")
                        {
                            MenuStrip strip = ctrl as MenuStrip;
                            strip.Items["mnsRegister"].Enabled = true;
                            strip.Items["mnsManage"].Enabled = true;
                            strip.Items["mnsReport"].Enabled = true;
                            strip.Items["mnsLogin"].Enabled = false;
                        }
                    }
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Login Failed!! Please enter correct Username or Password");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //forgot password Click event to handle the password change
        private void llbForgotPass_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmResetPassword rpForm = new frmResetPassword();
            rpForm.Show();
            this.Close();
        }
    }
}