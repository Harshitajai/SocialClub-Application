﻿//*********************************************************************************************
//// -----------------------------------------------------------------------
// <copyright file="frmReports.cs" Developed By = "Harshita and Priyanka">
// De Socia club - Here We can see Report of member, Event and activity 
// </copyright>
// -----------------------------------------------------------------------

//*******************************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DeSocialDataAccessLayer;

namespace DeSocialClub
{
    public partial class frmReport : Form
    {
        public frmReport()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        ReportLinqDataContext data = new ReportLinqDataContext();

        private void btnViewAllActivity_Click(object sender, EventArgs e)
        {
            var command = (from activity in data.Activities select new { ActivityID = activity.Activity_Id, ActivityName = activity.Activity_Name, ActivityDescription = activity.Activity_Description });
            dgvDisplayActivity.DataSource = command.ToList();
        }

        private void btnMemberViewAll_Click(object sender, EventArgs e)
        {
            var command = (from member in data.Members select new { Member_ID = member.Member_Id, Name = member.Name, Dob = member.Dob, EmailID = member.Email_Id, Contact = member.Contact, Address = member.Address, Gender = member.Gender, IsMarried = member.IsMarried, FamilyCount = member.Family_Count, Facility = member.Facility, MemberShipType = member.Membership_Type, Activity = member.Activity, Charge = member.Fee });
            dgvDisplayMember.DataSource = command.ToList();
        }

        private void btnViewAllEvent_Click(object sender, EventArgs e)
        {
            var command = (from events in data.Events select new { EventID = events.Event_Id, Name = events.Event_Name, Description = events.Event_Description, Date = events.Event_DateTime, Charge = events.Event_Charge, Venue = events.Event_Venue });
            dgvDisplayEvent.DataSource = command.ToList();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            var command = (from eventId in data.Events select eventId.Event_Id);
            cmbEventID.DataSource = command.ToList();
            var command1 = (from activityId in data.Activities select activityId.Activity_Id);
            cmbActivityId.DataSource = command1.ToList();
        }

        private void btnEventSearch_Click(object sender, EventArgs e)
        {
            int val = Convert.ToInt32(cmbEventID.Text);
            var command = (from events in data.Events where events.Event_Id == val select new { EventID = events.Event_Id, Name = events.Event_Name, Description = events.Event_Description, Date = events.Event_DateTime, Charge = events.Event_Charge, Venue = events.Event_Venue });
            dgvDisplayEvent.DataSource = command.ToList();
        }

        private void btnMemberReport_Click(object sender, EventArgs e)
        {
            dgvDisplayMember.DataSource = "";
        }

        private void btnEventClear_Click(object sender, EventArgs e)
        {
            dgvDisplayEvent.DataSource = "";
        }

        private void btnActivityClear_Click(object sender, EventArgs e)
        {
            dgvDisplayActivity.DataSource = "";
        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            string membershipType = cmbMembershipType.Text;
            string facility = cmbFacility.Text;
            var command = (from member in data.Members where member.Membership_Type == membershipType && member.Facility == facility select new { Member_ID = member.Member_Id, Name = member.Name, Dob = member.Dob, EmailID = member.Email_Id, Contact = member.Contact, Address = member.Address, Gender = member.Gender, IsMarried = member.IsMarried, FamilyCount = member.Family_Count, Facility = member.Facility, MemberShipType = member.Membership_Type, Activity = member.Activity, Charge = member.Fee });
            dgvDisplayMember.DataSource = command.ToList();
        }

        private void btnActivitySearch_Click(object sender, EventArgs e)
        {
            int val = Convert.ToInt32(cmbActivityId.Text);
            var command = (from activity in data.Activities where activity.Activity_Id == val select new { ActivityID = activity.Activity_Id, ActivityName = activity.Activity_Name, ActivityDescription = activity.Activity_Description });
            dgvDisplayActivity.DataSource = command.ToList();
        }
    }
}