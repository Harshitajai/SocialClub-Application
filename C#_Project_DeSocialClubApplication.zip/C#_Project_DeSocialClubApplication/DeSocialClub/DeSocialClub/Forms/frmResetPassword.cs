﻿//*********************************************************************************************
//// -----------------------------------------------------------------------
// <copyright file="frmResetPassword.cs" Developed By = "Harshita and Priyanka">
// De Socia club - Here We can reset password in case we forgot it
// </copyright>
// -----------------------------------------------------------------------

//*******************************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DeSocialDataAccessLayer;

namespace DeSocialClub
{
    public partial class frmResetPassword : Form
    {
        public frmResetPassword()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        ReportLinqDataContext data = new ReportLinqDataContext();

        private void btnUpdatePassword_Click(object sender, EventArgs e)
        {
            var query = (from a in data.Logins where a.Username == txtUserName.Text select a).FirstOrDefault();

            if (txtNewPassword.Text == txtConfirmPassword.Text)
            {
                query.Password = txtNewPassword.Text;
                MessageBox.Show("Password updated sucessfully!! You can Login now with new password");
            }
            else
            {
                MessageBox.Show("Password and Confirm should be same");
            }
            try
            {
                data.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            txtUserName.Clear();
            txtNewPassword.Clear();
            txtConfirmPassword.Clear();
            this.Close();
         }
    }
}