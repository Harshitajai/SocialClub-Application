﻿namespace DeSocialClub
{
    partial class frmManageActivities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btnActivitySearch = new System.Windows.Forms.Button();
            this.lstDisplayResult = new System.Windows.Forms.ListBox();
            this.btnResetActivity = new System.Windows.Forms.Button();
            this.btnDeleteActivity = new System.Windows.Forms.Button();
            this.btnSaveActivity = new System.Windows.Forms.Button();
            this.txtActivityDescription = new System.Windows.Forms.TextBox();
            this.txtActivityName = new System.Windows.Forms.TextBox();
            this.txtActivityId = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btnActivitySearch);
            this.groupBox12.Controls.Add(this.lstDisplayResult);
            this.groupBox12.Controls.Add(this.btnResetActivity);
            this.groupBox12.Controls.Add(this.btnDeleteActivity);
            this.groupBox12.Controls.Add(this.btnSaveActivity);
            this.groupBox12.Controls.Add(this.txtActivityDescription);
            this.groupBox12.Controls.Add(this.txtActivityName);
            this.groupBox12.Controls.Add(this.txtActivityId);
            this.groupBox12.Controls.Add(this.label37);
            this.groupBox12.Controls.Add(this.label38);
            this.groupBox12.Controls.Add(this.label39);
            this.groupBox12.Location = new System.Drawing.Point(7, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(524, 313);
            this.groupBox12.TabIndex = 5;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Activity";
            // 
            // btnActivitySearch
            // 
            this.btnActivitySearch.Location = new System.Drawing.Point(184, 259);
            this.btnActivitySearch.Name = "btnActivitySearch";
            this.btnActivitySearch.Size = new System.Drawing.Size(75, 35);
            this.btnActivitySearch.TabIndex = 8;
            this.btnActivitySearch.Text = "Search";
            this.btnActivitySearch.UseVisualStyleBackColor = true;
            this.btnActivitySearch.Click += new System.EventHandler(this.btnActivitySearch_Click);
            // 
            // lstDisplayResult
            // 
            this.lstDisplayResult.FormattingEnabled = true;
            this.lstDisplayResult.Location = new System.Drawing.Point(6, 191);
            this.lstDisplayResult.Name = "lstDisplayResult";
            this.lstDisplayResult.Size = new System.Drawing.Size(512, 43);
            this.lstDisplayResult.TabIndex = 6;
            // 
            // btnResetActivity
            // 
            this.btnResetActivity.Location = new System.Drawing.Point(396, 259);
            this.btnResetActivity.Name = "btnResetActivity";
            this.btnResetActivity.Size = new System.Drawing.Size(75, 35);
            this.btnResetActivity.TabIndex = 10;
            this.btnResetActivity.Text = "Reset";
            this.btnResetActivity.UseVisualStyleBackColor = true;
            this.btnResetActivity.Click += new System.EventHandler(this.btnResetActivity_Click);
            // 
            // btnDeleteActivity
            // 
            this.btnDeleteActivity.Location = new System.Drawing.Point(291, 259);
            this.btnDeleteActivity.Name = "btnDeleteActivity";
            this.btnDeleteActivity.Size = new System.Drawing.Size(75, 35);
            this.btnDeleteActivity.TabIndex = 9;
            this.btnDeleteActivity.Text = "Delete";
            this.btnDeleteActivity.UseVisualStyleBackColor = true;
            this.btnDeleteActivity.Click += new System.EventHandler(this.btnDeleteActivity_Click);
            // 
            // btnSaveActivity
            // 
            this.btnSaveActivity.Location = new System.Drawing.Point(79, 259);
            this.btnSaveActivity.Name = "btnSaveActivity";
            this.btnSaveActivity.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnSaveActivity.Size = new System.Drawing.Size(75, 35);
            this.btnSaveActivity.TabIndex = 7;
            this.btnSaveActivity.Text = "Save";
            this.btnSaveActivity.UseVisualStyleBackColor = true;
            this.btnSaveActivity.Click += new System.EventHandler(this.btnSaveActivity_Click);
            // 
            // txtActivityDescription
            // 
            this.txtActivityDescription.Location = new System.Drawing.Point(141, 109);
            this.txtActivityDescription.Multiline = true;
            this.txtActivityDescription.Name = "txtActivityDescription";
            this.txtActivityDescription.Size = new System.Drawing.Size(256, 64);
            this.txtActivityDescription.TabIndex = 5;
            // 
            // txtActivityName
            // 
            this.txtActivityName.Location = new System.Drawing.Point(141, 70);
            this.txtActivityName.Name = "txtActivityName";
            this.txtActivityName.Size = new System.Drawing.Size(186, 20);
            this.txtActivityName.TabIndex = 3;
            // 
            // txtActivityId
            // 
            this.txtActivityId.Location = new System.Drawing.Point(141, 33);
            this.txtActivityId.Name = "txtActivityId";
            this.txtActivityId.Size = new System.Drawing.Size(186, 20);
            this.txtActivityId.TabIndex = 1;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(33, 117);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(60, 13);
            this.label37.TabIndex = 4;
            this.label37.Text = "Description";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(33, 78);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(72, 13);
            this.label38.TabIndex = 2;
            this.label38.Text = "Activity Name";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(33, 44);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(55, 13);
            this.label39.TabIndex = 0;
            this.label39.Text = "Activity ID";
            // 
            // frmManageActivities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 320);
            this.Controls.Add(this.groupBox12);
            this.Name = "frmManageActivities";
            this.Text = "frmManageActivities";
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btnResetActivity;
        private System.Windows.Forms.Button btnDeleteActivity;
        private System.Windows.Forms.Button btnSaveActivity;
        private System.Windows.Forms.TextBox txtActivityDescription;
        private System.Windows.Forms.TextBox txtActivityName;
        private System.Windows.Forms.TextBox txtActivityId;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ListBox lstDisplayResult;
        private System.Windows.Forms.Button btnActivitySearch;
    }
}