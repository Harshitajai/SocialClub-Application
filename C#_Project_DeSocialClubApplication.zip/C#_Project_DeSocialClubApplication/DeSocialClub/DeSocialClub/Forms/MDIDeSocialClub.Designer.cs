﻿namespace DeSocialClub
{
    partial class DeSocialClubMDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnsLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsRegister = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsMemberRegistration = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsExit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsManage = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsManageMember = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsManageEvent = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsManageActivities = new System.Windows.Forms.ToolStripMenuItem();
            this.mnsReport = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnsLogin,
            this.mnsRegister,
            this.mnsManage,
            this.mnsReport});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(896, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnsLogin
            // 
            this.mnsLogin.Name = "mnsLogin";
            this.mnsLogin.Size = new System.Drawing.Size(49, 20);
            this.mnsLogin.Text = "Login";
            this.mnsLogin.Click += new System.EventHandler(this.mnsLogin_Click);
            // 
            // mnsRegister
            // 
            this.mnsRegister.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnsMemberRegistration,
            this.mnsExit});
            this.mnsRegister.Enabled = false;
            this.mnsRegister.Name = "mnsRegister";
            this.mnsRegister.Size = new System.Drawing.Size(61, 20);
            this.mnsRegister.Text = "Register";
            // 
            // mnsMemberRegistration
            // 
            this.mnsMemberRegistration.Name = "mnsMemberRegistration";
            this.mnsMemberRegistration.Size = new System.Drawing.Size(185, 22);
            this.mnsMemberRegistration.Text = "Member Registration";
            this.mnsMemberRegistration.Click += new System.EventHandler(this.mnsMemberRegistration_Click);
            // 
            // mnsExit
            // 
            this.mnsExit.Name = "mnsExit";
            this.mnsExit.Size = new System.Drawing.Size(185, 22);
            this.mnsExit.Text = "Exit";
            this.mnsExit.Click += new System.EventHandler(this.mnsExit_Click);
            // 
            // mnsManage
            // 
            this.mnsManage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnsManageMember,
            this.mnsManageEvent,
            this.mnsManageActivities});
            this.mnsManage.Enabled = false;
            this.mnsManage.Name = "mnsManage";
            this.mnsManage.Size = new System.Drawing.Size(62, 20);
            this.mnsManage.Text = "Manage";
            // 
            // mnsManageMember
            // 
            this.mnsManageMember.Name = "mnsManageMember";
            this.mnsManageMember.Size = new System.Drawing.Size(168, 22);
            this.mnsManageMember.Text = "Manage Member";
            this.mnsManageMember.Click += new System.EventHandler(this.manageMemberToolStripMenuItem_Click_1);
            // 
            // mnsManageEvent
            // 
            this.mnsManageEvent.Name = "mnsManageEvent";
            this.mnsManageEvent.Size = new System.Drawing.Size(168, 22);
            this.mnsManageEvent.Text = "Manage Event";
            this.mnsManageEvent.Click += new System.EventHandler(this.mnsManageEvent_Click);
            // 
            // mnsManageActivities
            // 
            this.mnsManageActivities.Name = "mnsManageActivities";
            this.mnsManageActivities.Size = new System.Drawing.Size(168, 22);
            this.mnsManageActivities.Text = "Manage Activities";
            this.mnsManageActivities.Click += new System.EventHandler(this.mnsManageActivities_Click);
            // 
            // mnsReport
            // 
            this.mnsReport.Enabled = false;
            this.mnsReport.Name = "mnsReport";
            this.mnsReport.Size = new System.Drawing.Size(54, 20);
            this.mnsReport.Text = "Report";
            this.mnsReport.Click += new System.EventHandler(this.mnsReport_Click);
            // 
            // DeSocialClubMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 473);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.Name = "DeSocialClubMDI";
            this.Text = "De Social Club";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnsLogin;
        private System.Windows.Forms.ToolStripMenuItem mnsRegister;
        private System.Windows.Forms.ToolStripMenuItem mnsMemberRegistration;
        private System.Windows.Forms.ToolStripMenuItem mnsExit;
        private System.Windows.Forms.ToolStripMenuItem mnsManage;
        private System.Windows.Forms.ToolStripMenuItem mnsManageMember;
        private System.Windows.Forms.ToolStripMenuItem mnsManageEvent;
        private System.Windows.Forms.ToolStripMenuItem mnsManageActivities;
        private System.Windows.Forms.ToolStripMenuItem mnsReport;
    }
}

