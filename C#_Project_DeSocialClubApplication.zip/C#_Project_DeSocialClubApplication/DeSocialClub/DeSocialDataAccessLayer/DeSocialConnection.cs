﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Sql;
using System.Data;

namespace DeSocialDataAccessLayer
{
    public class DeSocialConnection
    {
        // Declaration of connection object
        private SqlConnection connection;
        string connectionString = ConfigurationManager.ConnectionStrings["DeSocialClubConnectionString"].ToString();

        //to establish connection to database
        public SqlConnection GetConnection()
        {
            if (connection == null)
                connection = new SqlConnection(connectionString);
            return connection;
        }

        //to open connection for performing oprations
        public void Open()
        {
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        // to close connection
        public void Close()
        {
            connection.Close();
        }

//************* to execute query to perform any opration of member into the database table **************

        public int ExecuteNonQuery(string procnameOrQuery, CommandType cmdType, SqlParameter param1 = null, SqlParameter param2 = null, SqlParameter param3 = null, SqlParameter param4 = null, SqlParameter param5 = null, SqlParameter param6 = null, SqlParameter param7 = null, SqlParameter param8 = null, SqlParameter param9 = null, SqlParameter param10 = null, SqlParameter param11 = null, SqlParameter param12 = null, SqlParameter param13 = null)
        {
            SqlCommand cmd = new SqlCommand(procnameOrQuery, this.GetConnection());
            cmd.CommandType = cmdType;

            //If there are query parameters, add them to the command
            if (param1 != null)
                cmd.Parameters.Add(param1);
            if (param2 != null)
                cmd.Parameters.Add(param2);
            if (param3 != null)
                cmd.Parameters.Add(param3);
            if (param4 != null)
                cmd.Parameters.Add(param4);
            if (param5 != null)
                cmd.Parameters.Add(param5);
            if (param6 != null)
                cmd.Parameters.Add(param6);
            if (param7 != null)
                cmd.Parameters.Add(param7);
            if (param8 != null)
                cmd.Parameters.Add(param8);
            if (param9 != null)
                cmd.Parameters.Add(param9);
            if (param10 != null)
                cmd.Parameters.Add(param10);
            if (param11 != null)
                cmd.Parameters.Add(param11);
            if (param12 != null)
                cmd.Parameters.Add(param12);
            if (param13 != null)
                cmd.Parameters.Add(param13);

            try
            {
                this.Open();
                return cmd.ExecuteNonQuery();
            }
            finally
            {
                this.Close();
                cmd.Dispose();
            }
        }

        public SqlDataReader GetReader(string procnameOrQuery, CommandType cmdType, SqlParameter param1 = null, SqlParameter param2 = null, SqlParameter param3 = null, SqlParameter param4 = null, SqlParameter param5 = null, SqlParameter param6 = null, SqlParameter param7 = null, SqlParameter param8 = null, SqlParameter param9 = null, SqlParameter param10 = null, SqlParameter param11 = null, SqlParameter param12 = null, SqlParameter param13 = null)
        {

            SqlCommand cmd = new SqlCommand(procnameOrQuery, this.GetConnection());
            cmd.CommandType = cmdType;

            if (param1 != null)
                cmd.Parameters.Add(param1);
            if (param2 != null)
                cmd.Parameters.Add(param2);
            if (param3 != null)
                cmd.Parameters.Add(param3);
            if (param4 != null)
                cmd.Parameters.Add(param4);
            if (param5 != null)
                cmd.Parameters.Add(param5);
            if (param6 != null)
                cmd.Parameters.Add(param6);
            if (param7 != null)
                cmd.Parameters.Add(param7);
            if (param8 != null)
                cmd.Parameters.Add(param8);
            if (param9 != null)
                cmd.Parameters.Add(param9);
            if (param10 != null)
                cmd.Parameters.Add(param10);
            if (param11 != null)
                cmd.Parameters.Add(param11);
            if (param12 != null)
                cmd.Parameters.Add(param12);
            if (param13 != null)
                cmd.Parameters.Add(param13);

            try
            {
                this.Open();
                return cmd.ExecuteReader();
            }
            finally
            {
                cmd.Dispose();
            }
        }
    }
}