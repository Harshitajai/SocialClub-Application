﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeSocialBusinessLayer
{
    public class Events<T> where T: Event
    {
        public void Add(Event e)
        { e.AddEvent(); }

        public void Delete(Event e)
        { e.DeleteEvent(); }

        public void Update(Event e)
        { e.UpdateEvent(); }
    }
}