﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeSocialDataAccessLayer;
using System.Data;
using System.Data.SqlClient;

namespace DeSocialBusinessLayer
{
   public class Event
    {
        public int Event_Id {get; set;}
        public string Event_Name { get; set; }
        public string Event_Description { get; set; }
        public DateTime Event_DateTime { get; set; }
        public double Event_Charge { get; set; }
        public string Event_Venue { get; set; }

        //Insert method to add events
        public void AddEvent()
        {
            string sql = "Insert INTO dbo.Event(Event_Id,Event_Name,Event_Description,Event_DateTime,Event_Charge,Event_Venue)"
           + "values (@Event_Id, @Event_Name, @Event_Description, @Event_DateTime, @Event_Charge, @Event_Venue)";
            QueryEvent(Event_Id, Event_Name, Event_Description,Event_DateTime, Event_Charge, Event_Venue, sql);
        }

        //Delete method to delete events
        public void DeleteEvent()
        {
            string sql = "DELETE FROM dbo.Event WHERE Event_Id = @Event_Id";
            QueryEvent(Event_Id, Event_Name, Event_Description, Event_DateTime, Event_Charge, Event_Venue, sql);
        }

        //Update method to update events
        public void UpdateEvent()
        {
            string sql = "Update Event SET Event_Id = @Event_Id, Event_Name = @Event_Name , Event_Description = @Event_Description, "
            + "Event_DateTime = @Event_DateTime, Event_Charge = @Event_Charge, Event_Venue = @Event_Venue WHERE Event_Id = @Event_Id";
            QueryEvent(Event_Id, Event_Name, Event_Description, Event_DateTime, Event_Charge, Event_Venue, sql);
        }

        //Method to query add, update and delete events
        public int QueryEvent(int id, string name, string description, DateTime date, double charge, string venue, string sql)
        {
            DeSocialConnection aConnection = new DeSocialConnection();
            SqlParameter param1 = new SqlParameter("@Event_Id", SqlDbType.Int);
            param1.Value = id;
            SqlParameter param2 = new SqlParameter("@Event_Name", SqlDbType.Text);
            param2.Value = name;
            SqlParameter param3 = new SqlParameter("@Event_Description", SqlDbType.Text);
            param3.Value = description;
            SqlParameter param4 = new SqlParameter("@Event_DateTime", SqlDbType.DateTime);
            param4.Value = date;
            SqlParameter param5 = new SqlParameter("@Event_Charge", SqlDbType.Float);
            param5.Value = charge;
            SqlParameter param6 = new SqlParameter("@Event_Venue", SqlDbType.Text);
            param6.Value = venue;
            try
            {
                return aConnection.ExecuteNonQuery(sql, CommandType.Text, param1, param2, param3, param4, param5, param6);
            }
            catch (Exception ex)
            {
                return -1;
                throw new Exception(ex.Message);                
            }
        }

        //Method to get all events
        public SqlDataReader GetEvent(int id)
        {
            DeSocialConnection aConnection = new DeSocialConnection();
            SqlParameter param = new SqlParameter("@Event_Id", SqlDbType.Int);
            param.Value = id;
            try
            {
                SqlDataReader dr = aConnection.GetReader("SELECT Event_Id, Event_Name, Event_Description, Event_DateTime, Event_Charge, Event_Venue FROM Event WHERE Event_Id = @Event_Id", CommandType.Text, param); ;
                return dr;
            }
            catch (Exception ex)
            {
                return null;
                throw new Exception(ex.Message);
            }
        }

        //Method to display inserted events
        public override string ToString()
        {
            return ("Event saved into Database!! " + "  Event Id : " + Event_Id + " Event Name : " + Event_Name + " Event Description : " + Event_Description + " Event Date : " + Event_DateTime + " Event Charge : " + Event_Charge + " Event Venue : " + Event_Venue);
        }
    }
}