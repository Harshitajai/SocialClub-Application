﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeSocialDataAccessLayer;
using System.Data;
using System.Data.SqlClient;

namespace DeSocialBusinessLayer
{
    public class Activity
    {
        public int Activity_Id { get; set; }
        public string Activity_Name { get; set; }
        public string Activity_Description { get; set; }
        
        //Insert method to add activities
        public void Add()
        {
            string sql = "Insert INTO dbo.Activity(Activity_Id,Activity_Name,Activity_Description)"
           + "values (@Activity_Id, @Activity_Name, @Activity_Description)";
            QueryActivity(Activity_Id, Activity_Name, Activity_Description, sql);
        }

        //Delete method to delete activities
        public void Delete()
        {
            string sql = "DELETE FROM Activity WHERE Activity_Id = @Activity_Id";
            QueryActivity(Activity_Id, Activity_Name, Activity_Description, sql);
        }

        //Update method to update activities
        public void Update()
        {
            string sql = "Update Activity SET Activity_Id = @Activity_Id, Activity_Name = @Activity_Name ,"
            + "Activity_Description = @Activity_Description WHERE  Activity_Id = @Activity_Id";
            QueryActivity(Activity_Id, Activity_Name, Activity_Description, sql);
        }

        //Method to query add, update and delete activities
        public int QueryActivity(int id, string name, string description, string sql)
        {
            DeSocialConnection aConnection = new DeSocialConnection();
            SqlParameter param1 = new SqlParameter("@Activity_Id", SqlDbType.Int);
            param1.Value = id;
            SqlParameter param2 = new SqlParameter("@Activity_Name", SqlDbType.Text);
            param2.Value = name;
            SqlParameter param3 = new SqlParameter("@Activity_Description", SqlDbType.Text);
            param3.Value = description;
            try
            {
                return aConnection.ExecuteNonQuery(sql, CommandType.Text, param1, param2, param3);
            }
            catch (Exception ex)
            {
                return -1;
                throw new Exception(ex.Message);
            }
        }
    
        //Method to get all activites
        public SqlDataReader GetActivity(int id)
        {
            DeSocialConnection aConnection = new DeSocialConnection();
            SqlParameter param = new SqlParameter("@Activity_Id", SqlDbType.Int);
            param.Value = id;
            try
            {
                SqlDataReader dr = aConnection.GetReader("SELECT Activity_Id,Activity_Name,Activity_Description FROM Activity WHERE Activity_Id = @Activity_Id", CommandType.Text, param); ;
                return dr;
            }
            catch (Exception ex)
            {
                return null;
                throw new Exception(ex.Message);
            }
        }

        //Method to display inserted activity
        public override string ToString()
        {
            return ("Activity inserted into DataBase!! " + " Activity ID : " + Activity_Id + "  Activity Name : " + Activity_Name + " Activity Desctiption : " + Activity_Description);
        }
    }
}