﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeSocialBusinessLayer
{
    public interface IMember
    {
        int Member_Id { get; set; }
        string Name { get; set; }

        double CalculateTotalCharge();
    }
}