﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeSocialDataAccessLayer;
using System.Data.SqlClient;
using System.Data;

namespace DeSocialBusinessLayer
{
    public class Member :  MemberBase , IMember 
    {
        public int Member_Id { get; set; }
        public string Name { get; set; }
        public string Facility { get; set; }
        public string Membership_Type{ get; set; }
        public string Activity { get; set; }
        public double Charge { get; set; }

        const float ES_Standard = 50;
        const float ES_Gold = 70;
        const float ES_Platinum = 120;

        public event EventHandler AgeChecked;

        public bool Add()
        {

            int age = DateTime.Today.Year - Dob.Year;
            if (age < 18)
            {
                RaiseAgeChecked(EventArgs.Empty);
                return false;
            }
            else
                return true;
        }

        protected virtual void RaiseAgeChecked(EventArgs e)
        {
            EventHandler ageCheck = AgeChecked;
            if (ageCheck != null)
            {
                ageCheck(this, e);
            }
        }

        public double CalculateTotalCharge()
        {
            if (Facility == "Both" && Membership_Type == "Standard")
            { 
                Charge = (ES_Standard * 2) - (ES_Standard * 2 * 0.05);
            }
            else if (Facility == "Both" && Membership_Type == "Gold")
            { 
                Charge = (ES_Standard * 2) - (ES_Standard * 2 * 0.15); 
            }
            else if (Facility == "Both" && Membership_Type == "Platinum")
            { 
                Charge = (ES_Standard * 2) - (ES_Standard * 2 * 0.25); 
            }
            else if ((Facility == "Sports Club" || Facility == "Events") && (Membership_Type == "Standard"))
            { 
                Charge = 50; 
            }
            else if ((Facility == "Sports Club" || Facility == "Events") && (Membership_Type == "Gold"))
            { 
                Charge = 70; 
            }
            else if ((Facility == "Sports Club" || Facility == "Events") && (Membership_Type == "Platinum"))
            { 
                Charge = 120; 
            }
            return Charge;
        }

        public void AddMember()
        {
            string sql = "Insert INTO dbo.Member(Member_Id,Name,Dob,Email_Id,Contact,Address,Gender,IsMarried,Family_Count,Facility,Membership_Type,Activity,Fee)"
           + "values (@Member_Id, @Name, @Dob, @Email_Id, @Contact, @Address,@Gender,@IsMarried,@Family_Count,@Facility,@Membership_Type,@Activity,@Fee)";
            QueryMember(Member_Id, Name, Dob, Email_Id, Contact, Address, Gender, IsMarried, Family_Count, Facility, Membership_Type, Activity, Charge, sql);
        }

        public void DeleteMember()
        {
            string sql = "DELETE FROM dbo.Member WHERE Member_Id = @Member_Id";
            QueryMember(Member_Id, Name, Dob, Email_Id, Contact, Address, Gender, IsMarried, Family_Count, Facility, Membership_Type, Activity, Charge, sql);
        }
        public void UpdateMember()
        {
            string sql = "Update Member SET Name = @Name, Email_Id = @Email_Id, Contact = @Contact, Address = @Address, "
            + "IsMarried = @IsMarried,Family_Count = @Family_Count,Facility = @Facility,Membership_Type = @Membership_Type, "
            + "Activity = @Activity,Fee = @Fee WHERE Member_Id = @Member_Id";
            QueryMember(Member_Id, Name, Dob, Email_Id, Contact, Address, Gender, IsMarried, Family_Count, Facility, Membership_Type, Activity, Charge, sql);
        }

        public int QueryMember(int id, string name, DateTime dob, string email, string contact, string address, string gender, bool isMarried, int family_count, string facility, string membership_type, string activity, double fee , string sql)
        {
            DeSocialConnection aConnection = new DeSocialConnection();
            SqlParameter param1 = new SqlParameter("@Member_Id", SqlDbType.Int);
            param1.Value = id;
            SqlParameter param2 = new SqlParameter("@Name", SqlDbType.Text);
            param2.Value = name;
            SqlParameter param3 = new SqlParameter("@Dob", SqlDbType.DateTime);
            param3.Value = dob;
            SqlParameter param4 = new SqlParameter("@Email_Id", SqlDbType.Text);
            param4.Value = email;
            SqlParameter param5 = new SqlParameter("@Contact", SqlDbType.Text);
            param5.Value = contact;
            SqlParameter param6 = new SqlParameter("@Address", SqlDbType.Text);
            param6.Value = address;
            SqlParameter param7 = new SqlParameter("@Gender", SqlDbType.Text);
            param7.Value = gender;
            SqlParameter param8 = new SqlParameter("@IsMarried", SqlDbType.Bit);
            param8.Value = isMarried;
            SqlParameter param9 = new SqlParameter("@Family_Count", SqlDbType.Int);
            param9.Value = family_count;
            SqlParameter param10 = new SqlParameter("@Facility", SqlDbType.Text);
            param10.Value = facility;
            SqlParameter param11 = new SqlParameter("@Membership_Type", SqlDbType.Text);
            param11.Value = membership_type;
            SqlParameter param12 = new SqlParameter("@Activity", SqlDbType.Text);
            param12.Value = activity;
            SqlParameter param13 = new SqlParameter("@Fee", SqlDbType.Float);
            param13.Value = fee;

            try
            {
                return aConnection.ExecuteNonQuery(sql, CommandType.Text, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10, param11, param12, param13);
            }
            catch (Exception ex)
            {
                return -1;
                throw new Exception(ex.Message);
            }
        }

        public SqlDataReader GetMember(int id)
        {
            DeSocialConnection aConnection = new DeSocialConnection();
            SqlParameter param = new SqlParameter("@member_Id", SqlDbType.Int);
            param.Value = id;
            try
            {
                SqlDataReader dr = aConnection.GetReader("SELECT Member_Id,Name,Dob,Email_Id,Contact,Address,Gender,IsMarried,Family_Count,Facility,Membership_Type,Activity,Fee FROM Member WHERE Member_Id = @Member_Id", CommandType.Text, param); ;
                return dr;
            }
            catch (Exception ex)
            {
                return null;
                throw new Exception(ex.Message);
            }
        }

        public override string ToString()
        {
            return ("Member saved into Database!! " + "  Member Id : " + Member_Id + " Name : " + Name + " Email : " + Email_Id + " Contact : " + Contact + " Address : " + Address + " IsMarried : " + IsMarried + " Family Count : " + Family_Count + " Facility : " + Facility + " Membership Type : " + Membership_Type + " Activity : " + Activity);
        }
    }
}